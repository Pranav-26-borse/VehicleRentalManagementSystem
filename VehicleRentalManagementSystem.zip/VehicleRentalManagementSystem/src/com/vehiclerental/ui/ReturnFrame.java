package com.vehiclerental.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import com.vehiclerental.connection.DBConnection;

public class ReturnFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    private JComboBox<RentalItem> rentalComboBox;
    private JTextField rentalDateField;
    private JTextField plannedDaysField;
    private JTextField originalAmountField;
    private JTextField returnDateField;
    private JTextField lateDaysField;
    private JTextField lateFeeField;
    private JTextField totalAmountField;

    private JTable rentalTable;
    private DefaultTableModel tableModel;

    private final Color backgroundColor = new Color(245, 247, 250);
    private final Color cardColor = Color.WHITE;
    private final Color darkColor = new Color(31, 41, 55);
    private final Color accentColor = new Color(37, 99, 235);
    private final Color successColor = new Color(22, 163, 74);

    public ReturnFrame() {
        setTitle("V-RIDE - Return & Billing");
        setSize(1100, 720);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(0, 15));
        mainPanel.setBackground(backgroundColor);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("RETURN & BILLING");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 25));
        titleLabel.setForeground(darkColor);

        JLabel subtitleLabel = new JLabel("Complete vehicle returns and generate final rental bills");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitleLabel.setForeground(new Color(107, 114, 128));

        JPanel titlePanel = new JPanel(new BorderLayout(0, 4));
        titlePanel.setOpaque(false);
        titlePanel.add(titleLabel, BorderLayout.NORTH);
        titlePanel.add(subtitleLabel, BorderLayout.SOUTH);
        headerPanel.add(titlePanel, BorderLayout.WEST);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout(15, 15));
        centerPanel.setOpaque(false);

        JPanel formCard = new JPanel(new GridBagLayout());
        formCard.setBackground(cardColor);
        formCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(229, 231, 235)),
                BorderFactory.createEmptyBorder(18, 20, 18, 20)));

        JLabel formTitle = new JLabel("Return Vehicle");
        formTitle.setFont(new Font("Segoe UI", Font.BOLD, 17));
        formTitle.setForeground(darkColor);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 7, 6, 7);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formCard.add(formTitle, gbc);

        rentalComboBox = new JComboBox<>();
        rentalDateField = new JTextField();
        plannedDaysField = new JTextField();
        originalAmountField = new JTextField();
        returnDateField = new JTextField(LocalDate.now().toString());
        lateDaysField = new JTextField();
        lateFeeField = new JTextField();
        totalAmountField = new JTextField();

        rentalDateField.setEditable(false);
        plannedDaysField.setEditable(false);
        originalAmountField.setEditable(false);
        lateDaysField.setEditable(false);
        lateFeeField.setEditable(false);
        totalAmountField.setEditable(false);

        styleField(rentalComboBox);
        styleField(rentalDateField);
        styleField(plannedDaysField);
        styleField(originalAmountField);
        styleField(returnDateField);
        styleField(lateDaysField);
        styleField(lateFeeField);
        styleField(totalAmountField);

        int row = 1;
        addField(formCard, gbc, row++, "Active Rental", rentalComboBox);
        addField(formCard, gbc, row++, "Rental Date", rentalDateField);
        addField(formCard, gbc, row++, "Planned Days", plannedDaysField);
        addField(formCard, gbc, row++, "Original Amount", originalAmountField);
        addField(formCard, gbc, row++, "Actual Return Date", returnDateField);
        addField(formCard, gbc, row++, "Late Days", lateDaysField);
        addField(formCard, gbc, row++, "Late Fee", lateFeeField);
        addField(formCard, gbc, row++, "Final Amount", totalAmountField);

        JButton calculateButton = createButton("CALCULATE BILL", accentColor);
        JButton returnButton = createButton("RETURN VEHICLE", successColor);

        JPanel actionPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        actionPanel.setOpaque(false);
        actionPanel.add(calculateButton);
        actionPanel.add(returnButton);

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(12, 7, 4, 7);
        formCard.add(actionPanel, gbc);

        centerPanel.add(formCard, BorderLayout.NORTH);

        JPanel tableCard = new JPanel(new BorderLayout());
        tableCard.setBackground(cardColor);
        tableCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(229, 231, 235)),
                BorderFactory.createEmptyBorder(12, 12, 12, 12)));

        JLabel historyLabel = new JLabel("Rental History");
        historyLabel.setFont(new Font("Segoe UI", Font.BOLD, 17));
        historyLabel.setForeground(darkColor);
        historyLabel.setBorder(BorderFactory.createEmptyBorder(0, 3, 10, 0));

        String[] columns = {
                "Rental ID", "Customer", "Vehicle", "Rental Date",
                "Days", "Amount", "Status"
        };

        tableModel = new DefaultTableModel(columns, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        rentalTable = new JTable(tableModel);
        rentalTable.setRowHeight(34);
        rentalTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        rentalTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        rentalTable.getTableHeader().setPreferredSize(new Dimension(0, 36));
        rentalTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        rentalTable.setAutoCreateRowSorter(true);
        rentalTable.setShowGrid(false);
        rentalTable.setIntercellSpacing(new Dimension(0, 0));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        for (int i = 0; i < rentalTable.getColumnCount(); i++) {
            rentalTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JScrollPane scrollPane = new JScrollPane(rentalTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(229, 231, 235)));

        tableCard.add(historyLabel, BorderLayout.NORTH);
        tableCard.add(scrollPane, BorderLayout.CENTER);
        centerPanel.add(tableCard, BorderLayout.CENTER);
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setOpaque(false);

        JButton refreshButton = createButton("REFRESH", accentColor);
        JButton backButton = createButton("BACK", new Color(75, 85, 99));

        JPanel buttons = new JPanel(new GridLayout(1, 2, 10, 0));
        buttons.setOpaque(false);
        buttons.setPreferredSize(new Dimension(260, 42));
        buttons.add(refreshButton);
        buttons.add(backButton);

        bottomPanel.add(buttons, BorderLayout.EAST);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        rentalComboBox.addActionListener(e -> loadSelectedRentalDetails());
        calculateButton.addActionListener(e -> calculateBill());
        returnButton.addActionListener(e -> returnVehicle());
        refreshButton.addActionListener(e -> refreshData());
        backButton.addActionListener(e -> dispose());

        add(mainPanel);

        loadActiveRentals();
        loadRentalHistory();
    }

    private void styleField(javax.swing.JComponent component) {
        component.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        component.setPreferredSize(new Dimension(0, 34));
    }

    private void addField(
            JPanel panel,
            GridBagConstraints gbc,
            int row,
            String labelText,
            javax.swing.JComponent component) {

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(new Color(75, 85, 99));

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 1;
        gbc.weightx = 0.35;
        gbc.insets = new Insets(4, 7, 4, 10);
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.65;
        gbc.insets = new Insets(4, 7, 4, 7);
        panel.add(component, gbc);
    }

    private JButton createButton(String text, Color background) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(background);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        return button;
    }

    private void loadActiveRentals() {
        rentalComboBox.removeAllItems();

        String sql =
                "SELECT r.rental_id, c.full_name, v.vehicle_number, " +
                "r.rental_date, r.number_of_days, r.total_amount " +
                "FROM rentals r " +
                "JOIN customers c ON r.customer_id = c.customer_id " +
                "JOIN vehicles v ON r.vehicle_id = v.vehicle_id " +
                "WHERE r.status = 'ACTIVE' " +
                "ORDER BY r.rental_id";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet result = statement.executeQuery()) {

            while (result.next()) {
                rentalComboBox.addItem(new RentalItem(
                        result.getInt("rental_id"),
                        result.getString("full_name"),
                        result.getString("vehicle_number"),
                        result.getDate("rental_date"),
                        result.getInt("number_of_days"),
                        result.getDouble("total_amount")));
            }

            loadSelectedRentalDetails();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Could not load active rentals.\n\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadSelectedRentalDetails() {
        RentalItem rental = (RentalItem) rentalComboBox.getSelectedItem();

        if (rental == null) {
            rentalDateField.setText("");
            plannedDaysField.setText("");
            originalAmountField.setText("");
            lateDaysField.setText("");
            lateFeeField.setText("");
            totalAmountField.setText("");
            return;
        }

        rentalDateField.setText(rental.rentalDate.toString());
        plannedDaysField.setText(String.valueOf(rental.numberOfDays));
        originalAmountField.setText(String.format("₹ %.2f", rental.totalAmount));
        lateDaysField.setText("");
        lateFeeField.setText("");
        totalAmountField.setText("");
        returnDateField.setText(LocalDate.now().toString());
    }

    private void calculateBill() {
        RentalItem rental = (RentalItem) rentalComboBox.getSelectedItem();

        if (rental == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select an active rental.",
                    "No Rental Selected",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        String returnDateText = returnDateField.getText().trim();

        if (returnDateText.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter the return date.",
                    "Missing Information",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            LocalDate rentalDate = rental.rentalDate.toLocalDate();
            LocalDate returnDate = LocalDate.parse(returnDateText);

            if (returnDate.isBefore(rentalDate)) {
                JOptionPane.showMessageDialog(
                        this,
                        "Return date cannot be before rental date.",
                        "Invalid Date",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            long actualDays = ChronoUnit.DAYS.between(rentalDate, returnDate) + 1;
            long lateDays = Math.max(0, actualDays - rental.numberOfDays);
            double lateFee = lateDays * 500.00;
            double finalAmount = rental.totalAmount + lateFee;

            lateDaysField.setText(String.valueOf(lateDays));
            lateFeeField.setText(String.format("₹ %.2f", lateFee));
            totalAmountField.setText(String.format("₹ %.2f", finalAmount));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Invalid date format.\n\nUse format: YYYY-MM-DD",
                    "Invalid Date",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    private void returnVehicle() {
        RentalItem rental = (RentalItem) rentalComboBox.getSelectedItem();

        if (rental == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select an active rental.",
                    "No Rental Selected",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (lateDaysField.getText().trim().isEmpty()
                || lateFeeField.getText().trim().isEmpty()
                || totalAmountField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please calculate the bill first.",
                    "Calculate Bill",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        LocalDate returnDate;

        try {
            returnDate = LocalDate.parse(returnDateField.getText().trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Invalid return date.\n\nUse format: YYYY-MM-DD",
                    "Invalid Date",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        double lateFee = parseAmount(lateFeeField.getText());
        double totalAmount = parseAmount(totalAmountField.getText());
        int lateDays = Integer.parseInt(lateDaysField.getText());

        int confirmation = JOptionPane.showConfirmDialog(
                this,
                "Confirm vehicle return?\n\n" +
                "Customer: " + rental.customerName +
                "\nVehicle: " + rental.vehicleNumber +
                "\nLate Days: " + lateDays +
                "\nLate Fee: ₹" + String.format("%.2f", lateFee) +
                "\nFinal Amount: ₹" + String.format("%.2f", totalAmount),
                "Confirm Return",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (confirmation != JOptionPane.YES_OPTION) {
            return;
        }

        String getVehicleSql =
                "SELECT vehicle_id FROM rentals WHERE rental_id = ?";

        String updateRentalSql =
                "UPDATE rentals SET return_date = ?, late_fee = ?, " +
                "total_amount = ?, status = 'COMPLETED' WHERE rental_id = ?";

        String updateVehicleSql =
                "UPDATE vehicles SET status = 'AVAILABLE' WHERE vehicle_id = ?";

        Connection connection = null;

        try {
            connection = DBConnection.getConnection();
            connection.setAutoCommit(false);

            int vehicleId;

            try (PreparedStatement statement =
                    connection.prepareStatement(getVehicleSql)) {

                statement.setInt(1, rental.rentalId);

                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next()) {
                        throw new Exception("Rental record not found.");
                    }
                    vehicleId = result.getInt("vehicle_id");
                }
            }

            try (PreparedStatement statement =
                    connection.prepareStatement(updateRentalSql)) {

                statement.setDate(1, Date.valueOf(returnDate));
                statement.setDouble(2, lateFee);
                statement.setDouble(3, totalAmount);
                statement.setInt(4, rental.rentalId);

                if (statement.executeUpdate() == 0) {
                    throw new Exception("Rental could not be updated.");
                }
            }

            try (PreparedStatement statement =
                    connection.prepareStatement(updateVehicleSql)) {

                statement.setInt(1, vehicleId);

                if (statement.executeUpdate() == 0) {
                    throw new Exception("Vehicle status could not be updated.");
                }
            }

            connection.commit();

            showBill(rental, returnDate, lateDays, lateFee, totalAmount);

            clearForm();
            refreshData();

        } catch (Exception e) {
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (Exception rollbackException) {
                rollbackException.printStackTrace();
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Could not return vehicle.\n\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);

        } finally {
            try {
                if (connection != null) {
                    connection.setAutoCommit(true);
                    connection.close();
                }
            } catch (Exception closeException) {
                closeException.printStackTrace();
            }
        }
    }

    private double parseAmount(String value) {
        return Double.parseDouble(
                value.replace("₹", "").replace(",", "").trim());
    }

    private void showBill(
            RentalItem rental,
            LocalDate returnDate,
            int lateDays,
            double lateFee,
            double totalAmount) {

        String bill =
                "V-RIDE VEHICLE RENTAL\n" +
                "================================\n" +
                "Rental ID       : " + rental.rentalId + "\n" +
                "Customer        : " + rental.customerName + "\n" +
                "Vehicle         : " + rental.vehicleNumber + "\n" +
                "Rental Date     : " + rental.rentalDate + "\n" +
                "Return Date     : " + returnDate + "\n" +
                "Planned Days    : " + rental.numberOfDays + "\n" +
                "Late Days       : " + lateDays + "\n" +
                "Original Amount : ₹" + String.format("%.2f", rental.totalAmount) + "\n" +
                "Late Fee        : ₹" + String.format("%.2f", lateFee) + "\n" +
                "--------------------------------\n" +
                "FINAL AMOUNT    : ₹" + String.format("%.2f", totalAmount) + "\n" +
                "================================\n" +
                "Vehicle returned successfully.";

        JTextArea area = new JTextArea(bill);
        area.setFont(new Font("Monospaced", Font.PLAIN, 13));
        area.setEditable(false);
        area.setBackground(Color.WHITE);
        area.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JScrollPane pane = new JScrollPane(area);
        pane.setPreferredSize(new Dimension(480, 330));

        JOptionPane.showMessageDialog(
                this,
                pane,
                "Final Bill",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void loadRentalHistory() {
        String sql =
                "SELECT r.rental_id, c.full_name, v.vehicle_number, " +
                "r.rental_date, r.number_of_days, r.total_amount, r.status " +
                "FROM rentals r " +
                "JOIN customers c ON r.customer_id = c.customer_id " +
                "JOIN vehicles v ON r.vehicle_id = v.vehicle_id " +
                "ORDER BY r.rental_id DESC";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet result = statement.executeQuery()) {

            tableModel.setRowCount(0);

            while (result.next()) {
                tableModel.addRow(new Object[] {
                        result.getInt("rental_id"),
                        result.getString("full_name"),
                        result.getString("vehicle_number"),
                        result.getDate("rental_date"),
                        result.getInt("number_of_days"),
                        String.format("₹ %.2f", result.getDouble("total_amount")),
                        result.getString("status")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Could not load rental history.\n\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshData() {
        loadActiveRentals();
        loadRentalHistory();
    }

    private void clearForm() {
        rentalDateField.setText("");
        plannedDaysField.setText("");
        originalAmountField.setText("");
        returnDateField.setText(LocalDate.now().toString());
        lateDaysField.setText("");
        lateFeeField.setText("");
        totalAmountField.setText("");
    }

    private static class RentalItem {

        private int rentalId;
        private String customerName;
        private String vehicleNumber;
        private Date rentalDate;
        private int numberOfDays;
        private double totalAmount;

        public RentalItem(
                int rentalId,
                String customerName,
                String vehicleNumber,
                Date rentalDate,
                int numberOfDays,
                double totalAmount) {

            this.rentalId = rentalId;
            this.customerName = customerName;
            this.vehicleNumber = vehicleNumber;
            this.rentalDate = rentalDate;
            this.numberOfDays = numberOfDays;
            this.totalAmount = totalAmount;
        }

        @Override
        public String toString() {
            return "Rental #" + rentalId + " - " +
                    customerName + " - " + vehicleNumber;
        }
    }

    public static void main(String[] args) {
        ReturnFrame returnFrame = new ReturnFrame();
        returnFrame.setVisible(true);
    }
}