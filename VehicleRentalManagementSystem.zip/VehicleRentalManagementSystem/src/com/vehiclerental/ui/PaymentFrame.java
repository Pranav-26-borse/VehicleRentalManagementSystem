package com.vehiclerental.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDate;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import com.vehiclerental.dao.PaymentDAO;
import com.vehiclerental.dao.RentalDAO;

public class PaymentFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    private JComboBox<RentalItem> rentalComboBox;
    private JComboBox<String> paymentMethodComboBox;

    private JTextField amountField;
    private JTextField paymentDateField;

    private JTable paymentTable;
    private DefaultTableModel tableModel;

    private RentalDAO rentalDAO;
    private PaymentDAO paymentDAO;

    private JLabel revenueLabel;

    private final Color backgroundColor =
            new Color(245, 247, 250);

    private final Color primaryColor =
            new Color(25, 118, 210);

    private final Color primaryDarkColor =
            new Color(13, 71, 161);

    private final Color successColor =
            new Color(46, 125, 50);

    private final Color cardColor =
            Color.WHITE;

    private final Color textColor =
            new Color(35, 40, 45);

    private final Color secondaryTextColor =
            new Color(100, 108, 118);

    private final Color borderColor =
            new Color(220, 225, 230);

    public PaymentFrame() {

        rentalDAO = new RentalDAO();
        paymentDAO = new PaymentDAO();

        setTitle(
                "V-RIDE - Payment Management"
        );

        setSize(
                1100,
                700
        );

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        setLocationRelativeTo(null);

        setResizable(false);

        getContentPane().setBackground(
                backgroundColor
        );

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(
                                18,
                                18
                        )
                );

        mainPanel.setBackground(
                backgroundColor
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        25,
                        20,
                        25
                )
        );

        JPanel headerPanel =
                createHeaderPanel();

        JPanel paymentPanel =
                createPaymentPanel();

        JPanel historyPanel =
                createHistoryPanel();

        JPanel bottomPanel =
                createBottomPanel();

        mainPanel.add(
                headerPanel,
                BorderLayout.NORTH
        );

        JPanel centerPanel =
                new JPanel(
                        new BorderLayout(
                                15,
                                15
                        )
                );

        centerPanel.setOpaque(false);

        centerPanel.add(
                paymentPanel,
                BorderLayout.NORTH
        );

        centerPanel.add(
                historyPanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                centerPanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                bottomPanel,
                BorderLayout.SOUTH
        );

        add(mainPanel);

        loadCompletedRentals();
        loadPaymentHistory();
        updateRevenue();
    }

    private JPanel createHeaderPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setBackground(
                primaryDarkColor
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        16,
                        22,
                        16,
                        22
                )
        );

        JLabel titleLabel =
                new JLabel(
                        "PAYMENT MANAGEMENT"
                );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );

        titleLabel.setForeground(
                Color.WHITE
        );

        JLabel subtitleLabel =
                new JLabel(
                        "Record rental payments and view payment history"
                );

        subtitleLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        subtitleLabel.setForeground(
                new Color(
                        220,
                        235,
                        255
                )
        );

        JPanel textPanel =
                new JPanel(
                        new GridLayout(
                                2,
                                1,
                                0,
                                3
                        )
                );

        textPanel.setOpaque(false);

        textPanel.add(titleLabel);
        textPanel.add(subtitleLabel);

        JLabel brandLabel =
                new JLabel(
                        "V-RIDE"
                );

        brandLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        brandLabel.setForeground(
                Color.WHITE
        );

        panel.add(
                textPanel,
                BorderLayout.WEST
        );

        panel.add(
                brandLabel,
                BorderLayout.EAST
        );

        return panel;
    }

    private JPanel createPaymentPanel() {

        JPanel panel =
                new JPanel(
                        new GridBagLayout()
                );

        panel.setBackground(
                cardColor
        );

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                15,
                                18,
                                15,
                                18
                        )
                )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets =
                new Insets(
                        5,
                        7,
                        5,
                        7
                );

        gbc.fill =
                GridBagConstraints.HORIZONTAL;

        JLabel sectionTitle =
                new JLabel(
                        "RECORD NEW PAYMENT"
                );

        sectionTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        15
                )
        );

        sectionTitle.setForeground(
                textColor
        );

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 6;
        gbc.weightx = 1;

        panel.add(
                sectionTitle,
                gbc
        );

        rentalComboBox =
                new JComboBox<>();

        paymentMethodComboBox =
                new JComboBox<>(
                        new String[] {
                                "CASH",
                                "UPI",
                                "CARD"
                        }
                );

        amountField =
                new JTextField();

        paymentDateField =
                new JTextField(
                        LocalDate.now().toString()
                );

        amountField.setEditable(false);
        paymentDateField.setEditable(false);

        styleTextField(
                amountField
        );

        styleTextField(
                paymentDateField
        );

        styleComboBox(
                rentalComboBox
        );

        styleComboBox(
                paymentMethodComboBox
        );

        addLabel(
                panel,
                gbc,
                0,
                1,
                "Completed Rental"
        );

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.weightx = 1;

        panel.add(
                rentalComboBox,
                gbc
        );

        addLabel(
                panel,
                gbc,
                3,
                1,
                "Payment Amount"
        );

        gbc.gridx = 4;
        gbc.gridy = 1;
        gbc.gridwidth = 2;

        panel.add(
                amountField,
                gbc
        );

        addLabel(
                panel,
                gbc,
                0,
                2,
                "Payment Date"
        );

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;

        panel.add(
                paymentDateField,
                gbc
        );

        addLabel(
                panel,
                gbc,
                2,
                2,
                "Payment Method"
        );

        gbc.gridx = 3;
        gbc.gridy = 2;
        gbc.gridwidth = 1;

        panel.add(
                paymentMethodComboBox,
                gbc
        );

        JButton qrButton =
                createPrimaryButton(
                        "SHOW UPI QR"
                );

        JButton payButton =
                createSuccessButton(
                        "RECORD PAYMENT"
                );

        gbc.gridx = 4;
        gbc.gridy = 2;
        gbc.gridwidth = 1;

        panel.add(
                qrButton,
                gbc
        );

        gbc.gridx = 5;

        panel.add(
                payButton,
                gbc
        );

        rentalComboBox.addActionListener(
                e -> loadSelectedRentalAmount()
        );

        paymentMethodComboBox.addActionListener(
                e -> updateQRButton(qrButton)
        );

        qrButton.addActionListener(
                e -> showUPIQRCode()
        );

        payButton.addActionListener(
                e -> recordPayment()
        );

        updateQRButton(qrButton);

        return panel;
    }

    private void addLabel(
            JPanel panel,
            GridBagConstraints gbc,
            int x,
            int y,
            String text
    ) {

        JLabel label =
                new JLabel(
                        text
                );

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        label.setForeground(
                secondaryTextColor
        );

        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = 1;
        gbc.weightx = 0;

        panel.add(
                label,
                gbc
        );
    }

    private void styleTextField(
            JTextField field
    ) {

        field.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        field.setPreferredSize(
                new Dimension(
                        150,
                        34
                )
        );

        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                5,
                                8,
                                5,
                                8
                        )
                )
        );
    }

    private void styleComboBox(
            JComboBox<?> comboBox
    ) {

        comboBox.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        comboBox.setPreferredSize(
                new Dimension(
                        180,
                        34
                )
        );
    }

    private void updateQRButton(
            JButton button
    ) {

        Object selected =
                paymentMethodComboBox
                        .getSelectedItem();

        if (
                selected != null
                        && "UPI".equals(
                                selected.toString()
                        )
        ) {

            button.setEnabled(true);

        } else {

            button.setEnabled(false);
        }
    }

    private JPanel createHistoryPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setBackground(
                cardColor
        );

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                12,
                                12,
                                12,
                                12
                        )
                )
        );

        JPanel titlePanel =
                new JPanel(
                        new BorderLayout()
                );

        titlePanel.setOpaque(false);

        JLabel titleLabel =
                new JLabel(
                        "PAYMENT HISTORY"
                );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        15
                )
        );

        titleLabel.setForeground(
                textColor
        );

        revenueLabel =
                new JLabel(
                        "TOTAL REVENUE: ₹0.00"
                );

        revenueLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        revenueLabel.setForeground(
                successColor
        );

        titlePanel.add(
                titleLabel,
                BorderLayout.WEST
        );

        titlePanel.add(
                revenueLabel,
                BorderLayout.EAST
        );

        panel.add(
                titlePanel,
                BorderLayout.NORTH
        );

        String[] columns = {
                "PAYMENT ID",
                "RENTAL ID",
                "PAYMENT DATE",
                "AMOUNT",
                "METHOD",
                "STATUS"
        };

        tableModel =
                new DefaultTableModel(
                        columns,
                        0
                ) {

                    private static final long serialVersionUID = 1L;

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column
                    ) {

                        return false;
                    }
                };

        paymentTable =
                new JTable(
                        tableModel
                );

        paymentTable.setRowHeight(
                32
        );

        paymentTable.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        paymentTable.setForeground(
                textColor
        );

        paymentTable.setBackground(
                Color.WHITE
        );

        paymentTable.setGridColor(
                borderColor
        );

        paymentTable.setAutoCreateRowSorter(
                true
        );

        paymentTable.getTableHeader()
                .setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                12
                        )
                );

        paymentTable.getTableHeader()
                .setForeground(
                        textColor
                );

        paymentTable.getTableHeader()
                .setBackground(
                        new Color(
                                238,
                                241,
                                245
                        )
                );

        paymentTable.getTableHeader()
                .setPreferredSize(
                        new Dimension(
                                0,
                                36
                        )
                );

        paymentTable.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(100);

        paymentTable.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(100);

        paymentTable.getColumnModel()
                .getColumn(2)
                .setPreferredWidth(140);

        paymentTable.getColumnModel()
                .getColumn(3)
                .setPreferredWidth(130);

        paymentTable.getColumnModel()
                .getColumn(4)
                .setPreferredWidth(120);

        paymentTable.getColumnModel()
                .getColumn(5)
                .setPreferredWidth(120);

        DefaultTableCellRenderer centerRenderer =
                new DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        for (
                int i = 0;
                i < paymentTable
                        .getColumnCount();
                i++
        ) {

            paymentTable.getColumnModel()
                    .getColumn(i)
                    .setCellRenderer(
                            centerRenderer
                    );
        }

        JScrollPane scrollPane =
                new JScrollPane(
                        paymentTable
                );

        scrollPane.setBorder(
                BorderFactory.createLineBorder(
                        borderColor,
                        1
                )
        );

        panel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        return panel;
    }

    private JPanel createBottomPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setOpaque(false);

        JButton refreshButton =
                createSecondaryButton(
                        "REFRESH"
                );

        JButton clearButton =
                createSecondaryButton(
                        "CLEAR"
                );

        JButton backButton =
                createSecondaryButton(
                        "BACK"
                );

        JPanel leftPanel =
                new JPanel(
                        new GridLayout(
                                1,
                                2,
                                10,
                                0
                        )
                );

        leftPanel.setOpaque(false);

        leftPanel.add(
                refreshButton
        );

        leftPanel.add(
                clearButton
        );

        JPanel rightPanel =
                new JPanel(
                        new GridLayout(
                                1,
                                1
                        )
                );

        rightPanel.setOpaque(false);

        rightPanel.add(
                backButton
        );

        panel.add(
                leftPanel,
                BorderLayout.WEST
        );

        panel.add(
                rightPanel,
                BorderLayout.EAST
        );

        refreshButton.addActionListener(
                e -> refreshData()
        );

        clearButton.addActionListener(
                e -> clearForm()
        );

        backButton.addActionListener(
                e -> dispose()
        );

        return panel;
    }

    private JButton createPrimaryButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                primaryColor
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createEmptyBorder(
                        8,
                        15,
                        8,
                        15
                )
        );

        return button;
    }

    private JButton createSuccessButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                successColor
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createEmptyBorder(
                        8,
                        12,
                        8,
                        12
                )
        );

        return button;
    }

    private JButton createSecondaryButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                textColor
        );

        button.setBackground(
                new Color(
                        238,
                        241,
                        245
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createLineBorder(
                        borderColor,
                        1
                )
        );

        return button;
    }

    private void loadCompletedRentals() {

        rentalComboBox.removeAllItems();

        List<String[]> rentals =
                rentalDAO.getAllRentals();

        for (
                String[] rental
                        : rentals
        ) {

            if (
                    !"COMPLETED".equals(
                            rental[9]
                    )
            ) {

                continue;
            }

            int rentalId =
                    Integer.parseInt(
                            rental[0]
                    );

            String customerName =
                    rental[1];

            String vehicleNumber =
                    rental[2];

            double totalAmount =
                    Double.parseDouble(
                            rental[8]
                    );

            if (
                    !paymentDAO
                            .paymentExistsForRental(
                                    rentalId
                            )
            ) {

                rentalComboBox.addItem(
                        new RentalItem(
                                rentalId,
                                customerName,
                                vehicleNumber,
                                totalAmount
                        )
                );
            }
        }

        loadSelectedRentalAmount();
    }

    private void loadSelectedRentalAmount() {

        RentalItem rental =
                (RentalItem)
                        rentalComboBox
                                .getSelectedItem();

        if (rental == null) {

            amountField.setText("");

            return;
        }

        amountField.setText(
                String.format(
                        "₹%.2f",
                        rental.totalAmount
                )
        );
    }

    private void showUPIQRCode() {

        Object selected =
                paymentMethodComboBox
                        .getSelectedItem();

        if (
                selected == null
                        || !"UPI".equals(
                                selected.toString()
                        )
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select UPI as the payment method.",
                    "UPI Payment",
                    JOptionPane.INFORMATION_MESSAGE
            );

            return;
        }

        try {

            File qrFile =
                    new File(
                            "src"
                                    + File.separator
                                    + "admin_qr.png"
                    );

            if (!qrFile.exists()) {

                JOptionPane.showMessageDialog(
                        this,
                        "QR image not found.\n\n"
                                + qrFile.getAbsolutePath(),
                        "QR Code Error",
                        JOptionPane.ERROR_MESSAGE
                );

                return;
            }

            BufferedImage qrImage =
                    ImageIO.read(
                            qrFile
                    );

            if (qrImage == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Java could not read the QR image.",
                        "QR Code Error",
                        JOptionPane.ERROR_MESSAGE
                );

                return;
            }

            ImageIcon qrIcon =
                    new ImageIcon(
                            qrImage
                    );

            JLabel qrLabel =
                    new JLabel(
                            qrIcon
                    );

            qrLabel.setHorizontalAlignment(
                    SwingConstants.CENTER
            );

            JLabel titleLabel =
                    new JLabel(
                            "<html><center>"
                                    + "<b>ADMIN UPI PAYMENT</b><br>"
                                    + "Scan this QR code using any UPI app"
                                    + "</center></html>",
                            SwingConstants.CENTER
                    );

            titleLabel.setFont(
                    new Font(
                            "Arial",
                            Font.PLAIN,
                            13
                    )
            );

            JPanel qrPanel =
                    new JPanel(
                            new BorderLayout(
                                    10,
                                    10
                            )
                    );

            qrPanel.setBackground(
                    Color.WHITE
            );

            qrPanel.setBorder(
                    BorderFactory.createEmptyBorder(
                            15,
                            15,
                            15,
                            15
                    )
            );

            qrPanel.add(
                    qrLabel,
                    BorderLayout.CENTER
            );

            qrPanel.add(
                    titleLabel,
                    BorderLayout.SOUTH
            );

            JDialog dialog =
                    new JDialog(
                            this,
                            "Admin UPI QR Code",
                            true
                    );

            dialog.setContentPane(
                    qrPanel
            );

            dialog.setSize(
                    new Dimension(
                            420,
                            470
                    )
            );

            dialog.setResizable(false);

            dialog.setLocationRelativeTo(
                    this
            );

            dialog.setVisible(true);

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error displaying QR code.\n\n"
                            + e.getMessage(),
                    "QR Code Error",
                    JOptionPane.ERROR_MESSAGE
            );

            e.printStackTrace();
        }
    }

    private void recordPayment() {

        RentalItem rental =
                (RentalItem)
                        rentalComboBox
                                .getSelectedItem();

        if (rental == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a completed rental.",
                    "No Rental Selected",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        Object selectedMethod =
                paymentMethodComboBox
                        .getSelectedItem();

        if (selectedMethod == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a payment method.",
                    "Missing Payment Method",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        String method =
                selectedMethod.toString();

        double amount =
                rental.totalAmount;

        int confirmation =
                JOptionPane.showConfirmDialog(
                        this,
                        "Confirm payment?\n\n"
                                + "Rental ID: "
                                + rental.rentalId
                                + "\nCustomer: "
                                + rental.customerName
                                + "\nVehicle: "
                                + rental.vehicleNumber
                                + "\nAmount: ₹"
                                + String.format(
                                        "%.2f",
                                        amount
                                )
                                + "\nMethod: "
                                + method,
                        "Confirm Payment",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

        if (
                confirmation
                        != JOptionPane.YES_OPTION
        ) {

            return;
        }

        boolean recorded =
                paymentDAO.recordPayment(
                        rental.rentalId,
                        LocalDate.now().toString(),
                        amount,
                        method
                );

        if (recorded) {

            JOptionPane.showMessageDialog(
                    this,
                    "Payment recorded successfully!\n\n"
                            + "Amount: ₹"
                            + String.format(
                                    "%.2f",
                                    amount
                            )
                            + "\nMethod: "
                            + method,
                    "Payment Successful",
                    JOptionPane.INFORMATION_MESSAGE
            );

            refreshData();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not record payment.",
                    "Payment Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void loadPaymentHistory() {

        List<String[]> payments =
                paymentDAO.getPaymentHistory();

        tableModel.setRowCount(0);

        for (
                String[] payment
                        : payments
        ) {

            tableModel.addRow(
                    new Object[] {
                            Integer.parseInt(
                                    payment[0]
                            ),
                            Integer.parseInt(
                                    payment[1]
                            ),
                            payment[4],
                            String.format(
                                    "₹%.2f",
                                    Double.parseDouble(
                                            payment[5]
                                    )
                            ),
                            payment[6],
                            payment[7]
                    }
            );
        }
    }

    private void updateRevenue() {

        double revenue =
                paymentDAO.getTotalRevenue();

        revenueLabel.setText(
                String.format(
                        "TOTAL REVENUE: ₹%.2f",
                        revenue
                )
        );
    }

    private void refreshData() {

        paymentDateField.setText(
                LocalDate.now().toString()
        );

        loadCompletedRentals();
        loadPaymentHistory();
        updateRevenue();
    }

    private void clearForm() {

        if (
                rentalComboBox
                        .getItemCount()
                        > 0
        ) {

            rentalComboBox.setSelectedIndex(
                    0
            );
        }

        paymentMethodComboBox.setSelectedIndex(
                0
        );

        paymentDateField.setText(
                LocalDate.now().toString()
        );

        loadSelectedRentalAmount();
    }

    private static class RentalItem {

        private int rentalId;
        private String customerName;
        private String vehicleNumber;
        private double totalAmount;

        public RentalItem(
                int rentalId,
                String customerName,
                String vehicleNumber,
                double totalAmount
        ) {

            this.rentalId =
                    rentalId;

            this.customerName =
                    customerName;

            this.vehicleNumber =
                    vehicleNumber;

            this.totalAmount =
                    totalAmount;
        }

        @Override
        public String toString() {

            return "Rental #"
                    + rentalId
                    + " - "
                    + customerName
                    + " - "
                    + vehicleNumber
                    + " - ₹"
                    + String.format(
                            "%.2f",
                            totalAmount
                    );
        }
    }

    public static void main(
            String[] args
    ) {

        PaymentFrame paymentFrame =
                new PaymentFrame();

        paymentFrame.setVisible(true);
    }
}