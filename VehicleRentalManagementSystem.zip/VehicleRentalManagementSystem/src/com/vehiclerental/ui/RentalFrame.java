package com.vehiclerental.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import com.vehiclerental.dao.CustomerDAO;
import com.vehiclerental.dao.RentalDAO;
import com.vehiclerental.dao.VehicleDAO;

public class RentalFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    private JComboBox<CustomerItem> customerComboBox;
    private JComboBox<VehicleItem> vehicleComboBox;

    private JTextField daysField;
    private JTextField rentalAmountField;

    private JTable rentalTable;
    private DefaultTableModel tableModel;

    private CustomerDAO customerDAO;
    private VehicleDAO vehicleDAO;
    private RentalDAO rentalDAO;

    private final Color backgroundColor =
            new Color(245, 247, 250);

    private final Color primaryColor =
            new Color(25, 118, 210);

    private final Color primaryDarkColor =
            new Color(13, 71, 161);

    private final Color cardColor =
            Color.WHITE;

    private final Color textColor =
            new Color(35, 40, 45);

    private final Color secondaryTextColor =
            new Color(100, 108, 118);

    private final Color borderColor =
            new Color(220, 225, 230);

    public RentalFrame() {

        customerDAO = new CustomerDAO();
        vehicleDAO = new VehicleDAO();
        rentalDAO = new RentalDAO();

        setTitle(
                "V-RIDE - Rental Management"
        );

        setSize(
                1100,
                700
        );

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        setLocationRelativeTo(null);

        setResizable(false);

        getContentPane().setBackground(
                backgroundColor
        );

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(
                                18,
                                18
                        )
                );

        mainPanel.setBackground(
                backgroundColor
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        25,
                        20,
                        25
                )
        );

        JPanel headerPanel =
                createHeaderPanel();

        JPanel rentalPanel =
                createRentalPanel();

        JPanel tablePanel =
                createTablePanel();

        JPanel bottomPanel =
                createBottomPanel();

        mainPanel.add(
                headerPanel,
                BorderLayout.NORTH
        );

        JPanel centerPanel =
                new JPanel(
                        new BorderLayout(
                                15,
                                15
                        )
                );

        centerPanel.setOpaque(false);

        centerPanel.add(
                rentalPanel,
                BorderLayout.NORTH
        );

        centerPanel.add(
                tablePanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                centerPanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                bottomPanel,
                BorderLayout.SOUTH
        );

        add(mainPanel);

        loadCustomers();
        loadAvailableVehicles();
        loadRentals();
    }

    private JPanel createHeaderPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setBackground(
                primaryDarkColor
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        16,
                        22,
                        16,
                        22
                )
        );

        JLabel titleLabel =
                new JLabel(
                        "RENTAL MANAGEMENT"
                );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );

        titleLabel.setForeground(
                Color.WHITE
        );

        JLabel subtitleLabel =
                new JLabel(
                        "Create and manage vehicle rental transactions"
                );

        subtitleLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        subtitleLabel.setForeground(
                new Color(
                        220,
                        235,
                        255
                )
        );

        JPanel textPanel =
                new JPanel(
                        new GridLayout(
                                2,
                                1,
                                0,
                                3
                        )
                );

        textPanel.setOpaque(false);

        textPanel.add(titleLabel);
        textPanel.add(subtitleLabel);

        JLabel brandLabel =
                new JLabel(
                        "V-RIDE"
                );

        brandLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        brandLabel.setForeground(
                Color.WHITE
        );

        panel.add(
                textPanel,
                BorderLayout.WEST
        );

        panel.add(
                brandLabel,
                BorderLayout.EAST
        );

        return panel;
    }

    private JPanel createRentalPanel() {

        JPanel panel =
                new JPanel(
                        new GridBagLayout()
                );

        panel.setBackground(
                cardColor
        );

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                15,
                                18,
                                15,
                                18
                        )
                )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets =
                new Insets(
                        5,
                        7,
                        5,
                        7
                );

        gbc.fill =
                GridBagConstraints.HORIZONTAL;

        JLabel sectionTitle =
                new JLabel(
                        "CREATE NEW RENTAL"
                );

        sectionTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        15
                )
        );

        sectionTitle.setForeground(
                textColor
        );

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 6;
        gbc.weightx = 1;

        panel.add(
                sectionTitle,
                gbc
        );

        customerComboBox =
                new JComboBox<>();

        vehicleComboBox =
                new JComboBox<>();

        daysField =
                new JTextField();

        rentalAmountField =
                new JTextField();

        rentalAmountField.setEditable(false);

        styleTextField(daysField);
        styleTextField(rentalAmountField);

        styleComboBox(customerComboBox);
        styleComboBox(vehicleComboBox);

        addLabel(
                panel,
                gbc,
                0,
                1,
                "Customer"
        );

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.weightx = 1;

        panel.add(
                customerComboBox,
                gbc
        );

        addLabel(
                panel,
                gbc,
                3,
                1,
                "Vehicle"
        );

        gbc.gridx = 4;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.weightx = 1;

        panel.add(
                vehicleComboBox,
                gbc
        );

        addLabel(
                panel,
                gbc,
                0,
                2,
                "Number of Days"
        );

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.weightx = 1;

        panel.add(
                daysField,
                gbc
        );

        addLabel(
                panel,
                gbc,
                2,
                2,
                "Rental Amount"
        );

        gbc.gridx = 3;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.weightx = 1;

        panel.add(
                rentalAmountField,
                gbc
        );

        JButton calculateButton =
                createPrimaryButton(
                        "CALCULATE"
                );

        JButton rentButton =
                createSuccessButton(
                        "CREATE RENTAL"
                );

        gbc.gridx = 4;
        gbc.gridy = 2;
        gbc.gridwidth = 1;

        panel.add(
                calculateButton,
                gbc
        );

        gbc.gridx = 5;

        panel.add(
                rentButton,
                gbc
        );

        calculateButton.addActionListener(
                e -> calculateAmount()
        );

        rentButton.addActionListener(
                e -> createRental()
        );

        vehicleComboBox.addActionListener(
                e -> {

                    VehicleItem vehicle =
                            (VehicleItem)
                                    vehicleComboBox
                                            .getSelectedItem();

                    if (vehicle != null) {

                        String days =
                                daysField
                                        .getText()
                                        .trim();

                        if (!days.isEmpty()) {

                            calculateAmount();
                        }
                    }
                }
        );

        daysField.addActionListener(
                e -> calculateAmount()
        );

        return panel;
    }

    private void addLabel(
            JPanel panel,
            GridBagConstraints gbc,
            int x,
            int y,
            String text
    ) {

        JLabel label =
                new JLabel(
                        text
                );

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        label.setForeground(
                secondaryTextColor
        );

        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = 1;
        gbc.weightx = 0;

        panel.add(
                label,
                gbc
        );
    }

    private void styleTextField(
            JTextField field
    ) {

        field.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        field.setPreferredSize(
                new Dimension(
                        150,
                        34
                )
        );

        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                5,
                                8,
                                5,
                                8
                        )
                )
        );
    }

    private void styleComboBox(
            JComboBox<?> comboBox
    ) {

        comboBox.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        comboBox.setPreferredSize(
                new Dimension(
                        180,
                        34
                )
        );
    }

    private JPanel createTablePanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setBackground(
                cardColor
        );

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                12,
                                12,
                                12,
                                12
                        )
                )
        );

        JLabel titleLabel =
                new JLabel(
                        "RENTAL RECORDS"
                );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        15
                )
        );

        titleLabel.setForeground(
                textColor
        );

        titleLabel.setBorder(
                BorderFactory.createEmptyBorder(
                        0,
                        0,
                        10,
                        0
                )
        );

        panel.add(
                titleLabel,
                BorderLayout.NORTH
        );

        String[] columns = {
                "RENTAL ID",
                "CUSTOMER",
                "VEHICLE",
                "RENTAL DATE",
                "DAYS",
                "AMOUNT",
                "STATUS"
        };

        tableModel =
                new DefaultTableModel(
                        columns,
                        0
                ) {

                    private static final long serialVersionUID = 1L;

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column
                    ) {

                        return false;
                    }
                };

        rentalTable =
                new JTable(
                        tableModel
                );

        rentalTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        rentalTable.setRowHeight(
                32
        );

        rentalTable.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        rentalTable.setForeground(
                textColor
        );

        rentalTable.setBackground(
                Color.WHITE
        );

        rentalTable.setGridColor(
                borderColor
        );

        rentalTable.setAutoCreateRowSorter(
                true
        );

        rentalTable.getTableHeader()
                .setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                12
                        )
                );

        rentalTable.getTableHeader()
                .setForeground(
                        textColor
                );

        rentalTable.getTableHeader()
                .setBackground(
                        new Color(
                                238,
                                241,
                                245
                        )
                );

        rentalTable.getTableHeader()
                .setPreferredSize(
                        new Dimension(
                                0,
                                36
                        )
                );

        rentalTable.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(80);

        rentalTable.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(160);

        rentalTable.getColumnModel()
                .getColumn(2)
                .setPreferredWidth(130);

        rentalTable.getColumnModel()
                .getColumn(3)
                .setPreferredWidth(120);

        rentalTable.getColumnModel()
                .getColumn(4)
                .setPreferredWidth(70);

        rentalTable.getColumnModel()
                .getColumn(5)
                .setPreferredWidth(100);

        rentalTable.getColumnModel()
                .getColumn(6)
                .setPreferredWidth(110);

        DefaultTableCellRenderer centerRenderer =
                new DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        rentalTable.getColumnModel()
                .getColumn(0)
                .setCellRenderer(
                        centerRenderer
                );

        rentalTable.getColumnModel()
                .getColumn(3)
                .setCellRenderer(
                        centerRenderer
                );

        rentalTable.getColumnModel()
                .getColumn(4)
                .setCellRenderer(
                        centerRenderer
                );

        rentalTable.getColumnModel()
                .getColumn(5)
                .setCellRenderer(
                        centerRenderer
                );

        rentalTable.getColumnModel()
                .getColumn(6)
                .setCellRenderer(
                        centerRenderer
                );

        JScrollPane scrollPane =
                new JScrollPane(
                        rentalTable
                );

        scrollPane.setBorder(
                BorderFactory.createLineBorder(
                        borderColor,
                        1
                )
        );

        panel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        return panel;
    }

    private JPanel createBottomPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setOpaque(false);

        JButton refreshButton =
                createSecondaryButton(
                        "REFRESH"
                );

        JButton clearButton =
                createSecondaryButton(
                        "CLEAR"
                );

        JButton backButton =
                createSecondaryButton(
                        "BACK"
                );

        JPanel leftPanel =
                new JPanel(
                        new GridLayout(
                                1,
                                2,
                                10,
                                0
                        )
                );

        leftPanel.setOpaque(false);

        leftPanel.add(
                refreshButton
        );

        leftPanel.add(
                clearButton
        );

        JPanel rightPanel =
                new JPanel(
                        new GridLayout(
                                1,
                                1
                        )
                );

        rightPanel.setOpaque(false);

        rightPanel.add(
                backButton
        );

        panel.add(
                leftPanel,
                BorderLayout.WEST
        );

        panel.add(
                rightPanel,
                BorderLayout.EAST
        );

        refreshButton.addActionListener(
                e -> refreshData()
        );

        clearButton.addActionListener(
                e -> clearForm()
        );

        backButton.addActionListener(
                e -> dispose()
        );

        return panel;
    }

    private JButton createPrimaryButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                primaryColor
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createEmptyBorder(
                        8,
                        15,
                        8,
                        15
                )
        );

        return button;
    }

    private JButton createSuccessButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                new Color(
                        46,
                        125,
                        50
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createEmptyBorder(
                        8,
                        12,
                        8,
                        12
                )
        );

        return button;
    }

    private JButton createSecondaryButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                textColor
        );

        button.setBackground(
                new Color(
                        238,
                        241,
                        245
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createLineBorder(
                        borderColor,
                        1
                )
        );

        return button;
    }

    private void loadCustomers() {

        customerComboBox.removeAllItems();

        List<String[]> customers =
                customerDAO.getAllCustomers();

        for (
                String[] customer
                        : customers
        ) {

            customerComboBox.addItem(
                    new CustomerItem(
                            Integer.parseInt(
                                    customer[0]
                            ),
                            customer[1]
                    )
            );
        }
    }

    private void loadAvailableVehicles() {

        vehicleComboBox.removeAllItems();

        List<String[]> vehicles =
                vehicleDAO.getAllVehicles();

        for (
                String[] vehicle
                        : vehicles
        ) {

            if (
                    "AVAILABLE".equals(
                            vehicle[6]
                    )
            ) {

                vehicleComboBox.addItem(
                        new VehicleItem(
                                Integer.parseInt(
                                        vehicle[0]
                                ),
                                vehicle[1],
                                vehicle[2],
                                vehicle[3],
                                Double.parseDouble(
                                        vehicle[5]
                                )
                        )
                );
            }
        }

        rentalAmountField.setText("");
    }

    private void loadRentals() {

        List<String[]> rentals =
                rentalDAO.getAllRentals();

        tableModel.setRowCount(0);

        for (
                String[] rental
                        : rentals
        ) {

            String returnDate =
                    rental[4];

            String rentalDate =
                    rental[3];

            String displayDate =
                    rentalDate == null
                            ? ""
                            : rentalDate;

            String displayAmount =
                    String.format(
                            "₹%.2f",
                            Double.parseDouble(
                                    rental[8]
                            )
                    );

            String status =
                    rental[9];

            tableModel.addRow(
                    new Object[] {
                            Integer.parseInt(
                                    rental[0]
                            ),
                            rental[1],
                            rental[2],
                            displayDate,
                            Integer.parseInt(
                                    rental[5]
                            ),
                            displayAmount,
                            status
                    }
            );
        }

        TableRowSorter<?> sorter =
                (TableRowSorter<?>)
                        rentalTable.getRowSorter();

        if (sorter != null) {
            sorter.setSortKeys(null);
        }
    }

    private void calculateAmount() {

        VehicleItem vehicle =
                (VehicleItem)
                        vehicleComboBox
                                .getSelectedItem();

        if (vehicle == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select an available vehicle.",
                    "Missing Vehicle",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        String daysText =
                daysField
                        .getText()
                        .trim();

        if (daysText.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter number of days.",
                    "Missing Information",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        try {

            int days =
                    Integer.parseInt(
                            daysText
                    );

            if (days <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Number of days must be greater than 0.",
                        "Invalid Days",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }

            double amount =
                    vehicle.rentalRate
                            * days;

            rentalAmountField.setText(
                    String.format(
                            "₹%.2f",
                            amount
                    )
            );

        } catch (
                NumberFormatException e
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid number of days.",
                    "Invalid Input",
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }

    private void createRental() {

        CustomerItem customer =
                (CustomerItem)
                        customerComboBox
                                .getSelectedItem();

        VehicleItem vehicle =
                (VehicleItem)
                        vehicleComboBox
                                .getSelectedItem();

        if (customer == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a customer.",
                    "Missing Customer",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (vehicle == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "No available vehicle is currently selected.",
                    "Missing Vehicle",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        String daysText =
                daysField
                        .getText()
                        .trim();

        if (daysText.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter number of days.",
                    "Missing Information",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        int days;

        try {

            days =
                    Integer.parseInt(
                            daysText
                    );

        } catch (
                NumberFormatException e
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid number of days.",
                    "Invalid Input",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (days <= 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Number of days must be greater than 0.",
                    "Invalid Days",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        double rentalAmount =
                vehicle.rentalRate
                        * days;

        LocalDate today =
                LocalDate.now();

        int confirmation =
                JOptionPane.showConfirmDialog(
                        this,
                        "Create this rental?\n\n"
                                + "Customer: "
                                + customer.fullName
                                + "\nVehicle: "
                                + vehicle.vehicleNumber
                                + "\nRental Days: "
                                + days
                                + "\nTotal Amount: ₹"
                                + String.format(
                                        "%.2f",
                                        rentalAmount
                                ),
                        "Confirm Rental",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

        if (
                confirmation
                        != JOptionPane.YES_OPTION
        ) {

            return;
        }

        boolean success =
                rentalDAO.addRental(
                        customer.customerId,
                        vehicle.vehicleId,
                        today.toString(),
                        days,
                        rentalAmount,
                        0.00,
                        rentalAmount
                );

        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Rental created successfully!\n\n"
                            + "Customer: "
                            + customer.fullName
                            + "\nVehicle: "
                            + vehicle.vehicleNumber
                            + "\nDays: "
                            + days
                            + "\nAmount: ₹"
                            + String.format(
                                    "%.2f",
                                    rentalAmount
                            ),
                    "Rental Successful",
                    JOptionPane.INFORMATION_MESSAGE
            );

            clearForm();

            refreshData();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not create rental.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void clearForm() {

        daysField.setText("");
        rentalAmountField.setText("");

        if (
                customerComboBox
                        .getItemCount()
                        > 0
        ) {

            customerComboBox.setSelectedIndex(
                    0
            );
        }

        if (
                vehicleComboBox
                        .getItemCount()
                        > 0
        ) {

            vehicleComboBox.setSelectedIndex(
                    0
            );
        }
    }

    private void refreshData() {

        loadCustomers();
        loadAvailableVehicles();
        loadRentals();
    }

    private static class CustomerItem {

        private int customerId;
        private String fullName;

        public CustomerItem(
                int customerId,
                String fullName
        ) {

            this.customerId =
                    customerId;

            this.fullName =
                    fullName;
        }

        @Override
        public String toString() {

            return customerId
                    + " - "
                    + fullName;
        }
    }

    private static class VehicleItem {

        private int vehicleId;
        private String vehicleNumber;
        private String brand;
        private String model;
        private double rentalRate;

        public VehicleItem(
                int vehicleId,
                String vehicleNumber,
                String brand,
                String model,
                double rentalRate
        ) {

            this.vehicleId =
                    vehicleId;

            this.vehicleNumber =
                    vehicleNumber;

            this.brand =
                    brand;

            this.model =
                    model;

            this.rentalRate =
                    rentalRate;
        }

        @Override
        public String toString() {

            return vehicleNumber
                    + " - "
                    + brand
                    + " "
                    + model
                    + " (₹"
                    + String.format(
                            "%.2f",
                            rentalRate
                    )
                    + "/day)";
        }
    }

    public static void main(
            String[] args
    ) {

        RentalFrame rentalFrame =
                new RentalFrame();

        rentalFrame.setVisible(true);
    }
}