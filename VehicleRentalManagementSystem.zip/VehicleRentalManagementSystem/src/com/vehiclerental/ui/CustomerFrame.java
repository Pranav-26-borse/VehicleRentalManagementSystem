package com.vehiclerental.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import com.vehiclerental.dao.CustomerDAO;

public class CustomerFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    private JTextField nameField;
    private JTextField phoneField;
    private JTextField emailField;
    private JTextField addressField;
    private JTextField licenseField;
    private JTextField searchField;

    private JTable customerTable;
    private DefaultTableModel tableModel;

    private int selectedCustomerId = -1;

    private CustomerDAO customerDAO;

    private final Color backgroundColor =
            new Color(245, 247, 250);

    private final Color primaryColor =
            new Color(25, 118, 210);

    private final Color primaryDarkColor =
            new Color(13, 71, 161);

    private final Color cardColor =
            Color.WHITE;

    private final Color textColor =
            new Color(35, 40, 45);

    private final Color secondaryTextColor =
            new Color(100, 108, 118);

    private final Color borderColor =
            new Color(220, 225, 230);

    public CustomerFrame() {

        customerDAO = new CustomerDAO();

        setTitle(
                "V-RIDE - Customer Management"
        );

        setSize(
                1100,
                700
        );

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        setLocationRelativeTo(null);

        setResizable(false);

        getContentPane().setBackground(
                backgroundColor
        );

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(
                                18,
                                18
                        )
                );

        mainPanel.setBackground(
                backgroundColor
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        25,
                        20,
                        25
                )
        );

        JPanel headerPanel =
                createHeaderPanel();

        JPanel detailsPanel =
                createDetailsPanel();

        JPanel searchPanel =
                createSearchPanel();

        JPanel tablePanel =
                createTablePanel();

        JPanel bottomPanel =
                createBottomPanel();

        JPanel topContent =
                new JPanel(
                        new BorderLayout(
                                12,
                                12
                        )
                );

        topContent.setOpaque(false);

        topContent.add(
                detailsPanel,
                BorderLayout.CENTER
        );

        topContent.add(
                searchPanel,
                BorderLayout.SOUTH
        );

        mainPanel.add(
                headerPanel,
                BorderLayout.NORTH
        );

        JPanel centerPanel =
                new JPanel(
                        new BorderLayout(
                                15,
                                15
                        )
                );

        centerPanel.setOpaque(false);

        centerPanel.add(
                topContent,
                BorderLayout.NORTH
        );

        centerPanel.add(
                tablePanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                centerPanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                bottomPanel,
                BorderLayout.SOUTH
        );

        add(mainPanel);

        loadCustomers();
    }

    private JPanel createHeaderPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setBackground(
                primaryDarkColor
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        16,
                        22,
                        16,
                        22
                )
        );

        JLabel titleLabel =
                new JLabel(
                        "CUSTOMER MANAGEMENT"
                );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );

        titleLabel.setForeground(
                Color.WHITE
        );

        JLabel subtitleLabel =
                new JLabel(
                        "Manage customer information and driving license details"
                );

        subtitleLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        subtitleLabel.setForeground(
                new Color(
                        220,
                        235,
                        255
                )
        );

        JPanel textPanel =
                new JPanel(
                        new GridLayout(
                                2,
                                1,
                                0,
                                3
                        )
                );

        textPanel.setOpaque(false);

        textPanel.add(titleLabel);
        textPanel.add(subtitleLabel);

        JLabel brandLabel =
                new JLabel(
                        "V-RIDE"
                );

        brandLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        brandLabel.setForeground(
                Color.WHITE
        );

        panel.add(
                textPanel,
                BorderLayout.WEST
        );

        panel.add(
                brandLabel,
                BorderLayout.EAST
        );

        return panel;
    }

    private JPanel createDetailsPanel() {

        JPanel panel =
                new JPanel(
                        new GridBagLayout()
                );

        panel.setBackground(
                cardColor
        );

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                15,
                                18,
                                15,
                                18
                        )
                )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets =
                new Insets(
                        5,
                        7,
                        5,
                        7
                );

        gbc.fill =
                GridBagConstraints.HORIZONTAL;

        gbc.weightx = 0.0;

        JLabel sectionTitle =
                new JLabel(
                        "CUSTOMER DETAILS"
                );

        sectionTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        15
                )
        );

        sectionTitle.setForeground(
                textColor
        );

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 6;
        gbc.insets =
                new Insets(
                        0,
                        7,
                        10,
                        7
                );

        panel.add(
                sectionTitle,
                gbc
        );

        gbc.gridwidth = 1;
        gbc.insets =
                new Insets(
                        4,
                        7,
                        4,
                        7
                );

        addField(
                panel,
                gbc,
                0,
                1,
                "Full Name",
                nameField = new JTextField()
        );

        addField(
                panel,
                gbc,
                2,
                1,
                "Phone",
                phoneField = new JTextField()
        );

        addField(
                panel,
                gbc,
                4,
                1,
                "Email",
                emailField = new JTextField()
        );

        addField(
                panel,
                gbc,
                0,
                2,
                "Address",
                addressField = new JTextField()
        );

        addField(
                panel,
                gbc,
                2,
                2,
                "Driving License",
                licenseField = new JTextField()
        );

        JButton addButton =
                createPrimaryButton(
                        "ADD CUSTOMER"
                );

        JButton updateButton =
                createSecondaryButton(
                        "UPDATE CUSTOMER"
                );

        gbc.gridx = 4;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.weightx = 1;

        panel.add(
                addButton,
                gbc
        );

        gbc.gridx = 5;

        panel.add(
                updateButton,
                gbc
        );

        addButton.addActionListener(
                e -> addCustomer()
        );

        updateButton.addActionListener(
                e -> updateCustomer()
        );

        return panel;
    }

    private void addField(
            JPanel panel,
            GridBagConstraints gbc,
            int x,
            int y,
            String labelText,
            JTextField field
    ) {

        JLabel label =
                new JLabel(
                        labelText
                );

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        label.setForeground(
                secondaryTextColor
        );

        gbc.gridx = x;
        gbc.gridy = y;
        gbc.weightx = 0.0;

        panel.add(
                label,
                gbc
        );

        styleTextField(field);

        gbc.gridx = x + 1;
        gbc.weightx = 1.0;

        panel.add(
                field,
                gbc
        );
    }

    private void styleTextField(
            JTextField field
    ) {

        field.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        field.setPreferredSize(
                new Dimension(
                        150,
                        34
                )
        );

        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                5,
                                8,
                                5,
                                8
                        )
                )
        );
    }

    private JPanel createSearchPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout(
                                10,
                                0
                        )
                );

        panel.setBackground(
                cardColor
        );

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                10,
                                15,
                                10,
                                15
                        )
                )
        );

        JLabel searchLabel =
                new JLabel(
                        "SEARCH CUSTOMER"
                );

        searchLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        searchLabel.setForeground(
                secondaryTextColor
        );

        searchField =
                new JTextField();

        styleTextField(searchField);

        searchField.setPreferredSize(
                new Dimension(
                        300,
                        36
                )
        );

        JButton searchButton =
                createPrimaryButton(
                        "SEARCH"
                );

        JButton viewAllButton =
                createSecondaryButton(
                        "VIEW ALL"
                );

        JPanel inputPanel =
                new JPanel(
                        new BorderLayout(
                                8,
                                0
                        )
                );

        inputPanel.setOpaque(false);

        inputPanel.add(
                searchLabel,
                BorderLayout.WEST
        );

        inputPanel.add(
                searchField,
                BorderLayout.CENTER
        );

        JPanel buttonPanel =
                new JPanel(
                        new GridLayout(
                                1,
                                2,
                                8,
                                0
                        )
                );

        buttonPanel.setOpaque(false);

        buttonPanel.add(searchButton);
        buttonPanel.add(viewAllButton);

        panel.add(
                inputPanel,
                BorderLayout.CENTER
        );

        panel.add(
                buttonPanel,
                BorderLayout.EAST
        );

        searchButton.addActionListener(
                e -> searchCustomer()
        );

        viewAllButton.addActionListener(
                e -> loadCustomers()
        );

        searchField.addActionListener(
                e -> searchCustomer()
        );

        return panel;
    }

    private JPanel createTablePanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setBackground(
                cardColor
        );

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                12,
                                12,
                                12,
                                12
                        )
                )
        );

        String[] columns = {
                "ID",
                "FULL NAME",
                "PHONE",
                "EMAIL",
                "ADDRESS",
                "DRIVING LICENSE"
        };

        tableModel =
                new DefaultTableModel(
                        columns,
                        0
                ) {

                    private static final long serialVersionUID = 1L;

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column
                    ) {

                        return false;
                    }
                };

        customerTable =
                new JTable(
                        tableModel
                );

        customerTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        customerTable.setRowHeight(
                32
        );

        customerTable.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        customerTable.setForeground(
                textColor
        );

        customerTable.setBackground(
                Color.WHITE
        );

        customerTable.setGridColor(
                borderColor
        );

        customerTable.setShowVerticalLines(
                true
        );

        customerTable.setShowHorizontalLines(
                true
        );

        customerTable.setAutoCreateRowSorter(
                true
        );

        customerTable.getTableHeader()
                .setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                12
                        )
                );

        customerTable.getTableHeader()
                .setForeground(
                        textColor
                );

        customerTable.getTableHeader()
                .setBackground(
                        new Color(
                                238,
                                241,
                                245
                        )
                );

        customerTable.getTableHeader()
                .setPreferredSize(
                        new Dimension(
                                0,
                                36
                        )
                );

        customerTable.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(45);

        customerTable.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(170);

        customerTable.getColumnModel()
                .getColumn(2)
                .setPreferredWidth(120);

        customerTable.getColumnModel()
                .getColumn(3)
                .setPreferredWidth(190);

        customerTable.getColumnModel()
                .getColumn(4)
                .setPreferredWidth(170);

        customerTable.getColumnModel()
                .getColumn(5)
                .setPreferredWidth(150);

        JScrollPane scrollPane =
                new JScrollPane(
                        customerTable
                );

        scrollPane.setBorder(
                BorderFactory.createLineBorder(
                        borderColor,
                        1
                )
        );

        panel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        customerTable.getSelectionModel()
                .addListSelectionListener(
                        e -> {

                            if (
                                    !e.getValueIsAdjusting()
                            ) {

                                int viewRow =
                                        customerTable
                                                .getSelectedRow();

                                if (viewRow >= 0) {

                                    int row =
                                            customerTable
                                                    .convertRowIndexToModel(
                                                            viewRow
                                                    );

                                    selectedCustomerId =
                                            Integer.parseInt(
                                                    tableModel
                                                            .getValueAt(
                                                                    row,
                                                                    0
                                                            )
                                                            .toString()
                                            );

                                    setFieldValue(
                                            nameField,
                                            tableModel.getValueAt(
                                                    row,
                                                    1
                                            )
                                    );

                                    setFieldValue(
                                            phoneField,
                                            tableModel.getValueAt(
                                                    row,
                                                    2
                                            )
                                    );

                                    setFieldValue(
                                            emailField,
                                            tableModel.getValueAt(
                                                    row,
                                                    3
                                            )
                                    );

                                    setFieldValue(
                                            addressField,
                                            tableModel.getValueAt(
                                                    row,
                                                    4
                                            )
                                    );

                                    setFieldValue(
                                            licenseField,
                                            tableModel.getValueAt(
                                                    row,
                                                    5
                                            )
                                    );
                                }
                            }
                        }
                );

        customerTable.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    @Override
                    public void mouseClicked(
                            java.awt.event.MouseEvent e
                    ) {

                        if (e.getClickCount() == 2) {

                            int row =
                                    customerTable
                                            .getSelectedRow();

                            if (row >= 0) {

                                JOptionPane.showMessageDialog(
                                        CustomerFrame.this,
                                        "Customer selected for editing.",
                                        "Customer Selected",
                                        JOptionPane.INFORMATION_MESSAGE
                                );
                            }
                        }
                    }
                }
        );

        return panel;
    }

    private void setFieldValue(
            JTextField field,
            Object value
    ) {

        if (value == null) {

            field.setText("");

        } else {

            field.setText(
                    value.toString()
            );
        }
    }

    private JPanel createBottomPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setOpaque(false);

        JButton deleteButton =
                createDangerButton(
                        "DELETE CUSTOMER"
                );

        JButton clearButton =
                createSecondaryButton(
                        "CLEAR"
                );

        JButton backButton =
                createSecondaryButton(
                        "BACK"
                );

        JPanel leftPanel =
                new JPanel(
                        new GridLayout(
                                1,
                                2,
                                10,
                                0
                        )
                );

        leftPanel.setOpaque(false);

        leftPanel.add(deleteButton);
        leftPanel.add(clearButton);

        JPanel rightPanel =
                new JPanel(
                        new GridLayout(
                                1,
                                1
                        )
                );

        rightPanel.setOpaque(false);

        rightPanel.add(backButton);

        panel.add(
                leftPanel,
                BorderLayout.WEST
        );

        panel.add(
                rightPanel,
                BorderLayout.EAST
        );

        deleteButton.addActionListener(
                e -> deleteCustomer()
        );

        clearButton.addActionListener(
                e -> clearForm()
        );

        backButton.addActionListener(
                e -> dispose()
        );

        return panel;
    }

    private JButton createPrimaryButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                primaryColor
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createEmptyBorder(
                        8,
                        15,
                        8,
                        15
                )
        );

        return button;
    }

    private JButton createSecondaryButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                textColor
        );

        button.setBackground(
                new Color(
                        238,
                        241,
                        245
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createLineBorder(
                        borderColor,
                        1
                )
        );

        return button;
    }

    private JButton createDangerButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                new Color(
                        198,
                        40,
                        40
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createEmptyBorder(
                        8,
                        15,
                        8,
                        15
                )
        );

        return button;
    }

    private void addCustomer() {

        if (!validateFields()) {
            return;
        }

        String name =
                nameField.getText().trim();

        String phone =
                phoneField.getText().trim();

        String email =
                emailField.getText().trim();

        String address =
                addressField.getText().trim();

        String license =
                licenseField.getText().trim();

        boolean success =
                customerDAO.addCustomer(
                        name,
                        phone,
                        email.isEmpty()
                                ? null
                                : email,
                        address,
                        license
                );

        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Customer added successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            clearForm();

            loadCustomers();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not add customer.\n"
                            + "Phone, email or driving license may already exist.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void updateCustomer() {

        if (selectedCustomerId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a customer from the table first.",
                    "No Customer Selected",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (!validateFields()) {
            return;
        }

        String name =
                nameField.getText().trim();

        String phone =
                phoneField.getText().trim();

        String email =
                emailField.getText().trim();

        String address =
                addressField.getText().trim();

        String license =
                licenseField.getText().trim();

        boolean success =
                customerDAO.updateCustomer(
                        selectedCustomerId,
                        name,
                        phone,
                        email.isEmpty()
                                ? null
                                : email,
                        address,
                        license
                );

        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Customer updated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            clearForm();

            loadCustomers();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not update customer.\n"
                            + "Phone, email or driving license may already exist.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void deleteCustomer() {

        if (selectedCustomerId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a customer from the table first.",
                    "No Customer Selected",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        int confirmation =
                JOptionPane.showConfirmDialog(
                        this,
                        "Are you sure you want to delete this customer?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

        if (
                confirmation
                        != JOptionPane.YES_OPTION
        ) {

            return;
        }

        boolean success =
                customerDAO.deleteCustomer(
                        selectedCustomerId
                );

        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Customer deleted successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            clearForm();

            loadCustomers();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not delete customer.\n"
                            + "This customer may have rental records.",
                    "Delete Failed",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void searchCustomer() {

        String keyword =
                searchField.getText().trim();

        if (keyword.isEmpty()) {

            loadCustomers();

            return;
        }

        List<String[]> customers =
                customerDAO.searchCustomers(
                        keyword
                );

        tableModel.setRowCount(0);

        for (
                String[] customer
                        : customers
        ) {

            tableModel.addRow(
                    new Object[] {
                            Integer.parseInt(
                                    customer[0]
                            ),
                            customer[1],
                            customer[2],
                            customer[3],
                            customer[4],
                            customer[5]
                    }
            );
        }

        if (customers.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "No customer found for: "
                            + keyword,
                    "Search Result",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    private void loadCustomers() {

        List<String[]> customers =
                customerDAO.getAllCustomers();

        tableModel.setRowCount(0);

        for (
                String[] customer
                        : customers
        ) {

            tableModel.addRow(
                    new Object[] {
                            Integer.parseInt(
                                    customer[0]
                            ),
                            customer[1],
                            customer[2],
                            customer[3],
                            customer[4],
                            customer[5]
                    }
            );
        }

        if (customerTable != null) {

            TableRowSorter<?> sorter =
                    (TableRowSorter<?>)
                            customerTable.getRowSorter();

            if (sorter != null) {
                sorter.setSortKeys(null);
            }
        }
    }

    private boolean validateFields() {

        String name =
                nameField.getText().trim();

        String phone =
                phoneField.getText().trim();

        String email =
                emailField.getText().trim();

        String license =
                licenseField.getText().trim();

        if (
                name.isEmpty()
                        || phone.isEmpty()
                        || license.isEmpty()
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Full Name, Phone and Driving License are required.",
                    "Missing Information",
                    JOptionPane.WARNING_MESSAGE
            );

            return false;
        }

        if (!phone.matches("\\d{10}")) {

            JOptionPane.showMessageDialog(
                    this,
                    "Phone number must contain exactly 10 digits.",
                    "Invalid Phone",
                    JOptionPane.WARNING_MESSAGE
            );

            return false;
        }

        if (
                !email.isEmpty()
                        && !email.matches(
                                "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"
                        )
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid email address.",
                    "Invalid Email",
                    JOptionPane.WARNING_MESSAGE
            );

            return false;
        }

        if (name.length() < 2) {

            JOptionPane.showMessageDialog(
                    this,
                    "Full Name must contain at least 2 characters.",
                    "Invalid Name",
                    JOptionPane.WARNING_MESSAGE
            );

            return false;
        }

        return true;
    }

    private void clearForm() {

        nameField.setText("");
        phoneField.setText("");
        emailField.setText("");
        addressField.setText("");
        licenseField.setText("");
        searchField.setText("");

        selectedCustomerId = -1;

        if (customerTable != null) {
            customerTable.clearSelection();
        }

        if (nameField != null) {
            nameField.requestFocus();
        }
    }

    public static void main(
            String[] args
    ) {

        CustomerFrame customerFrame =
                new CustomerFrame();

        customerFrame.setVisible(true);
    }
}