package com.vehiclerental.ui;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class QRTest extends JFrame {

    private static final long serialVersionUID = 1L;

    public QRTest() {

        setTitle("QR Test");

        setSize(500, 600);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);

        try {

            File file =
                    new File(
                            "src"
                                    + File.separator
                                    + "admin_qr.png"
                    );

            System.out.println(
                    "QR path: "
                            + file.getAbsolutePath()
            );

            System.out.println(
                    "File exists: "
                            + file.exists()
            );

            System.out.println(
                    "File size: "
                            + file.length()
                            + " bytes"
            );

            BufferedImage image =
                    ImageIO.read(file);

            if (image == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "ImageIO returned NULL.\n"
                                + "Java cannot decode this image."
                );

                return;
            }

            System.out.println(
                    "Image loaded successfully!"
            );

            System.out.println(
                    "Width: "
                            + image.getWidth()
            );

            System.out.println(
                    "Height: "
                            + image.getHeight()
            );

            QRPanel qrPanel =
                    new QRPanel(image);

            add(
                    qrPanel,
                    BorderLayout.CENTER
            );

            add(
                    new JLabel(
                            "QR loaded successfully",
                            JLabel.CENTER
                    ),
                    BorderLayout.SOUTH
            );

        } catch (Exception e) {

            e.printStackTrace();

            JOptionPane.showMessageDialog(
                    this,
                    "ERROR:\n"
                            + e.getClass().getName()
                            + "\n\n"
                            + e.getMessage()
            );
        }
    }

    private static class QRPanel extends JPanel {

        private static final long serialVersionUID = 1L;

        private BufferedImage image;

        public QRPanel(BufferedImage image) {

            this.image = image;
        }

        @Override
        protected void paintComponent(
                Graphics g
        ) {

            super.paintComponent(g);

            int panelWidth =
                    getWidth();

            int panelHeight =
                    getHeight();

            int imageWidth =
                    image.getWidth();

            int imageHeight =
                    image.getHeight();

            double scale =
                    Math.min(
                            (double) panelWidth
                                    / imageWidth,
                            (double) panelHeight
                                    / imageHeight
                    );

            int newWidth =
                    (int)
                    (imageWidth * scale);

            int newHeight =
                    (int)
                    (imageHeight * scale);

            int x =
                    (panelWidth - newWidth)
                            / 2;

            int y =
                    (panelHeight - newHeight)
                            / 2;

            g.drawImage(
                    image,
                    x,
                    y,
                    newWidth,
                    newHeight,
                    this
            );
        }
    }

    public static void main(String[] args) {

        QRTest test =
                new QRTest();

        test.setVisible(true);
    }
}