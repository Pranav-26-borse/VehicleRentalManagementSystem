package com.vehiclerental.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import com.vehiclerental.dao.ReportDAO;

public class ReportFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    private JLabel totalVehiclesLabel;
    private JLabel availableVehiclesLabel;
    private JLabel rentedVehiclesLabel;
    private JLabel totalCustomersLabel;
    private JLabel totalRentalsLabel;
    private JLabel completedRentalsLabel;
    private JLabel totalRevenueLabel;

    private JTextArea reportArea;

    private ReportDAO reportDAO;

    private final Color backgroundColor =
            new Color(245, 247, 250);

    private final Color primaryColor =
            new Color(25, 118, 210);

    private final Color primaryDarkColor =
            new Color(13, 71, 161);

    private final Color successColor =
            new Color(46, 125, 50);

    private final Color warningColor =
            new Color(245, 124, 0);

    private final Color cardColor =
            Color.WHITE;

    private final Color textColor =
            new Color(35, 40, 45);

    private final Color secondaryTextColor =
            new Color(100, 108, 118);

    private final Color borderColor =
            new Color(220, 225, 230);

    public ReportFrame() {

        reportDAO =
                new ReportDAO();

        setTitle(
                "V-RIDE - Reports"
        );

        setSize(
                1100,
                700
        );

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        setLocationRelativeTo(null);

        setResizable(false);

        getContentPane().setBackground(
                backgroundColor
        );

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(
                                18,
                                18
                        )
                );

        mainPanel.setBackground(
                backgroundColor
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        25,
                        20,
                        25
                )
        );

        JPanel headerPanel =
                createHeaderPanel();

        JPanel statisticsPanel =
                createStatisticsPanel();

        JPanel reportPanel =
                createReportPanel();

        JPanel bottomPanel =
                createBottomPanel();

        mainPanel.add(
                headerPanel,
                BorderLayout.NORTH
        );

        JPanel centerPanel =
                new JPanel(
                        new BorderLayout(
                                15,
                                15
                        )
                );

        centerPanel.setOpaque(false);

        centerPanel.add(
                statisticsPanel,
                BorderLayout.WEST
        );

        centerPanel.add(
                reportPanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                centerPanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                bottomPanel,
                BorderLayout.SOUTH
        );

        add(mainPanel);

        loadReport();
    }

    private JPanel createHeaderPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setBackground(
                primaryDarkColor
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        16,
                        22,
                        16,
                        22
                )
        );

        JLabel titleLabel =
                new JLabel(
                        "REPORTS & STATISTICS"
                );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );

        titleLabel.setForeground(
                Color.WHITE
        );

        JLabel subtitleLabel =
                new JLabel(
                        "View system performance, rental activity and financial summary"
                );

        subtitleLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        subtitleLabel.setForeground(
                new Color(
                        220,
                        235,
                        255
                )
        );

        JPanel textPanel =
                new JPanel(
                        new GridLayout(
                                2,
                                1,
                                0,
                                3
                        )
                );

        textPanel.setOpaque(false);

        textPanel.add(
                titleLabel
        );

        textPanel.add(
                subtitleLabel
        );

        JLabel brandLabel =
                new JLabel(
                        "V-RIDE"
                );

        brandLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        brandLabel.setForeground(
                Color.WHITE
        );

        panel.add(
                textPanel,
                BorderLayout.WEST
        );

        panel.add(
                brandLabel,
                BorderLayout.EAST
        );

        return panel;
    }

    private JPanel createStatisticsPanel() {

        JPanel panel =
                new JPanel(
                        new GridLayout(
                                7,
                                1,
                                0,
                                8
                        )
                );

        panel.setBackground(
                backgroundColor
        );

        panel.setPreferredSize(
                new Dimension(
                        300,
                        0
                )
        );

        totalVehiclesLabel =
                createStatLabel(
                        "TOTAL VEHICLES",
                        primaryColor
                );

        availableVehiclesLabel =
                createStatLabel(
                        "AVAILABLE VEHICLES",
                        successColor
                );

        rentedVehiclesLabel =
                createStatLabel(
                        "RENTED VEHICLES",
                        warningColor
                );

        totalCustomersLabel =
                createStatLabel(
                        "TOTAL CUSTOMERS",
                        primaryColor
                );

        totalRentalsLabel =
                createStatLabel(
                        "TOTAL RENTALS",
                        primaryColor
                );

        completedRentalsLabel =
                createStatLabel(
                        "COMPLETED RENTALS",
                        successColor
                );

        totalRevenueLabel =
                createStatLabel(
                        "TOTAL REVENUE",
                        successColor
                );

        panel.add(
                createStatCard(
                        "TOTAL VEHICLES",
                        totalVehiclesLabel
                )
        );

        panel.add(
                createStatCard(
                        "AVAILABLE VEHICLES",
                        availableVehiclesLabel
                )
        );

        panel.add(
                createStatCard(
                        "RENTED VEHICLES",
                        rentedVehiclesLabel
                )
        );

        panel.add(
                createStatCard(
                        "TOTAL CUSTOMERS",
                        totalCustomersLabel
                )
        );

        panel.add(
                createStatCard(
                        "TOTAL RENTALS",
                        totalRentalsLabel
                )
        );

        panel.add(
                createStatCard(
                        "COMPLETED RENTALS",
                        completedRentalsLabel
                )
        );

        panel.add(
                createStatCard(
                        "TOTAL REVENUE",
                        totalRevenueLabel
                )
        );

        return panel;
    }

    private JLabel createStatLabel(
            String title,
            Color color
    ) {

        JLabel label =
                new JLabel(
                        "0",
                        SwingConstants.CENTER
                );

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        22
                )
        );

        label.setForeground(
                color
        );

        return label;
    }

    private JPanel createStatCard(
            String title,
            JLabel valueLabel
    ) {

        JPanel card =
                new JPanel(
                        new BorderLayout(
                                5,
                                3
                        )
                );

        card.setBackground(
                cardColor
        );

        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                8,
                                10,
                                8,
                                10
                        )
                )
        );

        JLabel titleLabel =
                new JLabel(
                        title,
                        SwingConstants.CENTER
                );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        11
                )
        );

        titleLabel.setForeground(
                secondaryTextColor
        );

        card.add(
                titleLabel,
                BorderLayout.NORTH
        );

        card.add(
                valueLabel,
                BorderLayout.CENTER
        );

        return card;
    }

    private JPanel createReportPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setBackground(
                cardColor
        );

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                15,
                                15,
                                15,
                                15
                        )
                )
        );

        JLabel titleLabel =
                new JLabel(
                        "DETAILED SYSTEM REPORT"
                );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        titleLabel.setForeground(
                textColor
        );

        titleLabel.setBorder(
                BorderFactory.createEmptyBorder(
                        0,
                        0,
                        12,
                        0
                )
        );

        panel.add(
                titleLabel,
                BorderLayout.NORTH
        );

        reportArea =
                new JTextArea();

        reportArea.setEditable(false);

        reportArea.setLineWrap(true);

        reportArea.setWrapStyleWord(true);

        reportArea.setFont(
                new Font(
                        "Monospaced",
                        Font.PLAIN,
                        14
                )
        );

        reportArea.setForeground(
                textColor
        );

        reportArea.setBackground(
                new Color(
                        250,
                        251,
                        253
                )
        );

        reportArea.setBorder(
                BorderFactory.createEmptyBorder(
                        15,
                        15,
                        15,
                        15
                )
        );

        JScrollPane scrollPane =
                new JScrollPane(
                        reportArea
                );

        scrollPane.setBorder(
                BorderFactory.createLineBorder(
                        borderColor,
                        1
                )
        );

        panel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        return panel;
    }

    private JPanel createBottomPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setOpaque(false);

        JButton refreshButton =
                createPrimaryButton(
                        "REFRESH REPORT"
                );

        JButton vehicleReportButton =
                createSecondaryButton(
                        "VEHICLE REPORT"
                );

        JButton backButton =
                createSecondaryButton(
                        "BACK"
                );

        JPanel leftPanel =
                new JPanel(
                        new GridLayout(
                                1,
                                2,
                                10,
                                0
                        )
                );

        leftPanel.setOpaque(false);

        leftPanel.add(
                refreshButton
        );

        leftPanel.add(
                vehicleReportButton
        );

        JPanel rightPanel =
                new JPanel(
                        new GridLayout(
                                1,
                                1
                        )
                );

        rightPanel.setOpaque(false);

        rightPanel.add(
                backButton
        );

        panel.add(
                leftPanel,
                BorderLayout.WEST
        );

        panel.add(
                rightPanel,
                BorderLayout.EAST
        );

        refreshButton.addActionListener(
                e -> loadReport()
        );

        vehicleReportButton.addActionListener(
                e -> showVehicleReport()
        );

        backButton.addActionListener(
                e -> dispose()
        );

        return panel;
    }

    private JButton createPrimaryButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                primaryColor
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createEmptyBorder(
                        9,
                        15,
                        9,
                        15
                )
        );

        return button;
    }

    private JButton createSecondaryButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                textColor
        );

        button.setBackground(
                new Color(
                        238,
                        241,
                        245
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createLineBorder(
                        borderColor,
                        1
                )
        );

        return button;
    }

    private void loadReport() {

        try {

            int totalVehicles =
                    reportDAO.getTotalVehicles();

            int availableVehicles =
                    reportDAO.getAvailableVehicles();

            int rentedVehicles =
                    reportDAO.getRentedVehicles();

            int totalCustomers =
                    reportDAO.getTotalCustomers();

            int totalRentals =
                    reportDAO.getTotalRentals();

            int completedRentals =
                    reportDAO.getCompletedRentals();

            double totalRevenue =
                    reportDAO.getTotalRevenue();

            totalVehiclesLabel.setText(
                    String.valueOf(
                            totalVehicles
                    )
            );

            availableVehiclesLabel.setText(
                    String.valueOf(
                            availableVehicles
                    )
            );

            rentedVehiclesLabel.setText(
                    String.valueOf(
                            rentedVehicles
                    )
            );

            totalCustomersLabel.setText(
                    String.valueOf(
                            totalCustomers
                    )
            );

            totalRentalsLabel.setText(
                    String.valueOf(
                            totalRentals
                    )
            );

            completedRentalsLabel.setText(
                    String.valueOf(
                            completedRentals
                    )
            );

            totalRevenueLabel.setText(
                    String.format(
                            Locale.US,
                            "₹%.2f",
                            totalRevenue
                    )
            );

            StringBuilder report =
                    new StringBuilder();

            report.append(
                    "V-RIDE VEHICLE RENTAL MANAGEMENT SYSTEM\n"
            );

            report.append(
                    "========================================\n\n"
            );

            report.append(
                    "VEHICLE SUMMARY\n"
            );

            report.append(
                    "----------------------------------------\n"
            );

            report.append(
                    "Total Vehicles       : "
            );

            report.append(
                    totalVehicles
            );

            report.append("\n");

            report.append(
                    "Available Vehicles   : "
            );

            report.append(
                    availableVehicles
            );

            report.append("\n");

            report.append(
                    "Rented Vehicles      : "
            );

            report.append(
                    rentedVehicles
            );

            report.append("\n\n");

            report.append(
                    "CUSTOMER SUMMARY\n"
            );

            report.append(
                    "----------------------------------------\n"
            );

            report.append(
                    "Total Customers      : "
            );

            report.append(
                    totalCustomers
            );

            report.append("\n\n");

            report.append(
                    "RENTAL SUMMARY\n"
            );

            report.append(
                    "----------------------------------------\n"
            );

            report.append(
                    "Total Rentals        : "
            );

            report.append(
                    totalRentals
            );

            report.append("\n");

            report.append(
                    "Completed Rentals    : "
            );

            report.append(
                    completedRentals
            );

            report.append("\n");

            report.append(
                    "Active Rentals       : "
            );

            report.append(
                    totalRentals
                            - completedRentals
            );

            report.append("\n\n");

            report.append(
                    "FINANCIAL SUMMARY\n"
            );

            report.append(
                    "----------------------------------------\n"
            );

            report.append(
                    "Total Revenue        : ₹"
            );

            report.append(
                    String.format(
                            Locale.US,
                            "%.2f",
                            totalRevenue
                    )
            );

            report.append("\n\n");

            report.append(
                    "REPORT STATUS\n"
            );

            report.append(
                    "----------------------------------------\n"
            );

            report.append(
                    "Data loaded successfully from database."
            );

            reportArea.setText(
                    report.toString()
            );

            reportArea.setCaretPosition(
                    0
            );

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not load report.\n\n"
                            + e.getMessage(),
                    "Report Error",
                    JOptionPane.ERROR_MESSAGE
            );

            e.printStackTrace();
        }
    }

    private void showVehicleReport() {

        try {

            int totalVehicles =
                    reportDAO.getTotalVehicles();

            int availableVehicles =
                    reportDAO.getAvailableVehicles();

            int rentedVehicles =
                    reportDAO.getRentedVehicles();

            int maintenanceVehicles =
                    totalVehicles
                            - availableVehicles
                            - rentedVehicles;

            String report =
                    "VEHICLE STATUS REPORT\n\n"
                            + "Total Vehicles: "
                            + totalVehicles
                            + "\n\n"
                            + "Available Vehicles: "
                            + availableVehicles
                            + "\n"
                            + "Rented Vehicles: "
                            + rentedVehicles
                            + "\n"
                            + "Other Status Vehicles: "
                            + maintenanceVehicles
                            + "\n";

            JOptionPane.showMessageDialog(
                    this,
                    report,
                    "Vehicle Report",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not generate vehicle report.\n\n"
                            + e.getMessage(),
                    "Report Error",
                    JOptionPane.ERROR_MESSAGE
            );

            e.printStackTrace();
        }
    }

    public static void main(
            String[] args
    ) {

        ReportFrame reportFrame =
                new ReportFrame();

        reportFrame.setVisible(true);
    }
}