package com.vehiclerental.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.vehiclerental.connection.DBConnection;

public class LoginFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    private JTextField usernameField;
    private JPasswordField passwordField;

    private final Color backgroundColor = new Color(245, 247, 250);
    private final Color cardColor = Color.WHITE;
    private final Color primaryColor = new Color(25, 118, 210);
    private final Color primaryDarkColor = new Color(13, 71, 161);
    private final Color textColor = new Color(35, 40, 45);
    private final Color secondaryTextColor = new Color(100, 108, 118);
    private final Color borderColor = new Color(220, 225, 230);

    public LoginFrame() {

        setTitle("V-RIDE - Vehicle Rental Management System");

        setSize(900, 560);

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setLocationRelativeTo(null);

        setResizable(false);

        getContentPane().setBackground(
                backgroundColor
        );

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout()
                );

        mainPanel.setBackground(
                backgroundColor
        );

        mainPanel.setBorder(
                new EmptyBorder(
                        35,
                        45,
                        35,
                        45
                )
        );

        JPanel leftPanel =
                createLeftPanel();

        JPanel rightPanel =
                createLoginPanel();

        mainPanel.add(
                leftPanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                rightPanel,
                BorderLayout.EAST
        );

        add(mainPanel);
    }

    private JPanel createLeftPanel() {

        JPanel panel =
                new JPanel(
                        new GridBagLayout()
                );

        panel.setBackground(
                primaryDarkColor
        );

        panel.setPreferredSize(
                new Dimension(
                        430,
                        480
                )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.gridx = 0;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets =
                new Insets(
                        8,
                        35,
                        8,
                        35
                );

        JLabel logoLabel =
                new JLabel(
                        "V-RIDE",
                        SwingConstants.CENTER
                );

        logoLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        44
                )
        );

        logoLabel.setForeground(
                Color.WHITE
        );

        gbc.gridy = 0;
        gbc.insets =
                new Insets(
                        20,
                        35,
                        5,
                        35
                );

        panel.add(
                logoLabel,
                gbc
        );

        JLabel subtitleLabel =
                new JLabel(
                        "VEHICLE RENTAL MANAGEMENT",
                        SwingConstants.CENTER
                );

        subtitleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        15
                )
        );

        subtitleLabel.setForeground(
                new Color(
                        220,
                        235,
                        255
                )
        );

        gbc.gridy = 1;
        gbc.insets =
                new Insets(
                        0,
                        35,
                        35,
                        35
                );

        panel.add(
                subtitleLabel,
                gbc
        );

        JLabel descriptionLabel =
                new JLabel(
                        "<html><div style='text-align:center;'>"
                                + "A simple and efficient platform<br>"
                                + "for managing vehicles, customers,<br>"
                                + "rentals and payments."
                                + "</div></html>",
                        SwingConstants.CENTER
                );

        descriptionLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        descriptionLabel.setForeground(
                Color.WHITE
        );

        gbc.gridy = 2;
        gbc.insets =
                new Insets(
                        0,
                        35,
                        30,
                        35
                );

        panel.add(
                descriptionLabel,
                gbc
        );

        JLabel featureTitle =
                new JLabel(
                        "SYSTEM FEATURES",
                        SwingConstants.CENTER
                );

        featureTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        featureTitle.setForeground(
                Color.WHITE
        );

        gbc.gridy = 3;
        gbc.insets =
                new Insets(
                        5,
                        35,
                        12,
                        35
                );

        panel.add(
                featureTitle,
                gbc
        );

        JLabel featuresLabel =
                new JLabel(
                        "<html><div style='text-align:left;'>"
                                + "✓ Vehicle Management<br><br>"
                                + "✓ Customer Management<br><br>"
                                + "✓ Rental Management<br><br>"
                                + "✓ Payment Management<br><br>"
                                + "✓ Reports & Statistics"
                                + "</div></html>"
                );

        featuresLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        featuresLabel.setForeground(
                Color.WHITE
        );

        gbc.gridy = 4;
        gbc.insets =
                new Insets(
                        0,
                        65,
                        20,
                        35
                );

        panel.add(
                featuresLabel,
                gbc
        );

        return panel;
    }

    private JPanel createLoginPanel() {

        JPanel outerPanel =
                new JPanel(
                        new GridBagLayout()
                );

        outerPanel.setBackground(
                backgroundColor
        );

        outerPanel.setPreferredSize(
                new Dimension(
                        380,
                        480
                )
        );

        JPanel cardPanel =
                new JPanel(
                        new GridBagLayout()
                );

        cardPanel.setBackground(
                cardColor
        );

        cardPanel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        new EmptyBorder(
                                30,
                                35,
                                30,
                                35
                        )
                )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.gridx = 0;
        gbc.weightx = 1;
        gbc.fill =
                GridBagConstraints.HORIZONTAL;
        gbc.insets =
                new Insets(
                        7,
                        0,
                        7,
                        0
                );

        JLabel welcomeLabel =
                new JLabel(
                        "Welcome Back",
                        SwingConstants.CENTER
                );

        welcomeLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );

        welcomeLabel.setForeground(
                textColor
        );

        gbc.gridy = 0;
        gbc.insets =
                new Insets(
                        5,
                        0,
                        5,
                        0
                );

        cardPanel.add(
                welcomeLabel,
                gbc
        );

        JLabel loginSubtitle =
                new JLabel(
                        "Sign in to continue",
                        SwingConstants.CENTER
                );

        loginSubtitle.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        loginSubtitle.setForeground(
                secondaryTextColor
        );

        gbc.gridy = 1;
        gbc.insets =
                new Insets(
                        0,
                        0,
                        25,
                        0
                );

        cardPanel.add(
                loginSubtitle,
                gbc
        );

        JLabel usernameLabel =
                new JLabel(
                        "Username"
                );

        usernameLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        usernameLabel.setForeground(
                textColor
        );

        gbc.gridy = 2;
        gbc.insets =
                new Insets(
                        5,
                        0,
                        5,
                        0
                );

        cardPanel.add(
                usernameLabel,
                gbc
        );

        usernameField =
                new JTextField();

        usernameField.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        usernameField.setPreferredSize(
                new Dimension(
                        280,
                        40
                )
        );

        usernameField.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        new EmptyBorder(
                                5,
                                10,
                                5,
                                10
                        )
                )
        );

        gbc.gridy = 3;
        gbc.insets =
                new Insets(
                        0,
                        0,
                        12,
                        0
                );

        cardPanel.add(
                usernameField,
                gbc
        );

        JLabel passwordLabel =
                new JLabel(
                        "Password"
                );

        passwordLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        passwordLabel.setForeground(
                textColor
        );

        gbc.gridy = 4;
        gbc.insets =
                new Insets(
                        5,
                        0,
                        5,
                        0
                );

        cardPanel.add(
                passwordLabel,
                gbc
        );

        passwordField =
                new JPasswordField();

        passwordField.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        passwordField.setPreferredSize(
                new Dimension(
                        280,
                        40
                )
        );

        passwordField.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        new EmptyBorder(
                                5,
                                10,
                                5,
                                10
                        )
                )
        );

        gbc.gridy = 5;
        gbc.insets =
                new Insets(
                        0,
                        0,
                        22,
                        0
                );

        cardPanel.add(
                passwordField,
                gbc
        );

        JButton loginButton =
                new JButton(
                        "LOGIN"
                );

        loginButton.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        loginButton.setForeground(
                Color.WHITE
        );

        loginButton.setBackground(
                primaryColor
        );

        loginButton.setFocusPainted(
                false
        );

        loginButton.setBorder(
                BorderFactory.createEmptyBorder(
                        10,
                        10,
                        10,
                        10
                )
        );

        gbc.gridy = 6;
        gbc.insets =
                new Insets(
                        0,
                        0,
                        10,
                        0
                );

        cardPanel.add(
                loginButton,
                gbc
        );

        JButton clearButton =
                new JButton(
                        "CLEAR"
                );

        clearButton.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );

        clearButton.setForeground(
                textColor
        );

        clearButton.setBackground(
                new Color(
                        238,
                        241,
                        245
                )
        );

        clearButton.setFocusPainted(
                false
        );

        clearButton.setBorder(
                BorderFactory.createLineBorder(
                        borderColor,
                        1
                )
        );

        gbc.gridy = 7;
        gbc.insets =
                new Insets(
                        0,
                        0,
                        20,
                        0
                );

        cardPanel.add(
                clearButton,
                gbc
        );

        JLabel footerLabel =
                new JLabel(
                        "Secure Vehicle Rental Management",
                        SwingConstants.CENTER
                );

        footerLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        12
                )
        );

        footerLabel.setForeground(
                secondaryTextColor
        );

        gbc.gridy = 8;
        gbc.insets =
                new Insets(
                        5,
                        0,
                        0,
                        0
                );

        cardPanel.add(
                footerLabel,
                gbc
        );

        outerPanel.add(
                cardPanel
        );

        loginButton.addActionListener(
                e -> login()
        );

        clearButton.addActionListener(
                e -> {

                    usernameField.setText("");
                    passwordField.setText("");
                    usernameField.requestFocus();
                }
        );

        passwordField.addActionListener(
                e -> login()
        );

        return outerPanel;
    }

    private void login() {

        String username =
                usernameField
                        .getText()
                        .trim();

        String password =
                new String(
                        passwordField
                                .getPassword()
                );

        if (
                username.isEmpty()
                        || password.isEmpty()
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter username and password.",
                    "Missing Information",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        String sql =
                "SELECT role FROM users "
                        + "WHERE username = ? "
                        + "AND password = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(
                                sql
                        )
        ) {

            statement.setString(
                    1,
                    username
            );

            statement.setString(
                    2,
                    password
            );

            ResultSet result =
                    statement.executeQuery();

            if (result.next()) {

                String role =
                        result.getString(
                                "role"
                        );

                JOptionPane.showMessageDialog(
                        this,
                        "Login successful!\nRole: "
                                + role,
                        "Login Successful",
                        JOptionPane.INFORMATION_MESSAGE
                );

                dispose();

                DashboardFrame dashboard =
                        new DashboardFrame();

                dashboard.setVisible(true);

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Invalid username or password.",
                        "Login Failed",
                        JOptionPane.ERROR_MESSAGE
                );

                passwordField.setText("");
                passwordField.requestFocus();
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Database error:\n"
                            + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            e.printStackTrace();
        }
    }

    public static void main(
            String[] args
    ) {

        LoginFrame loginFrame =
                new LoginFrame();

        loginFrame.setVisible(true);
    }
}