package com.vehiclerental.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import com.vehiclerental.dao.ReportDAO;

public class DashboardFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    private JLabel totalVehiclesLabel;
    private JLabel availableVehiclesLabel;
    private JLabel totalCustomersLabel;
    private JLabel activeRentalsLabel;

    private ReportDAO reportDAO;

    private final Color backgroundColor = new Color(245, 247, 250);
    private final Color primaryColor = new Color(25, 118, 210);
    private final Color primaryDarkColor = new Color(13, 71, 161);
    private final Color cardColor = Color.WHITE;
    private final Color textColor = new Color(35, 40, 45);
    private final Color secondaryTextColor = new Color(100, 108, 118);
    private final Color borderColor = new Color(220, 225, 230);

    public DashboardFrame() {

        setTitle("V-RIDE - Dashboard");

        setSize(1000, 650);

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setLocationRelativeTo(null);

        setResizable(false);

        getContentPane().setBackground(
                backgroundColor
        );

        reportDAO = new ReportDAO();

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(
                                20,
                                20
                        )
                );

        mainPanel.setBackground(
                backgroundColor
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        25,
                        30,
                        25,
                        30
                )
        );

        JPanel headerPanel =
                new JPanel(
                        new BorderLayout()
                );

        headerPanel.setBackground(
                primaryDarkColor
        );

        headerPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        18,
                        25,
                        18,
                        25
                )
        );

        JLabel titleLabel =
                new JLabel(
                        "V-RIDE"
                );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        30
                )
        );

        titleLabel.setForeground(
                Color.WHITE
        );

        JLabel subtitleLabel =
                new JLabel(
                        "Vehicle Rental Management System"
                );

        subtitleLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        subtitleLabel.setForeground(
                new Color(
                        220,
                        235,
                        255
                )
        );

        JPanel headerTextPanel =
                new JPanel(
                        new GridLayout(
                                2,
                                1,
                                0,
                                2
                        )
                );

        headerTextPanel.setOpaque(
                false
        );

        headerTextPanel.add(
                titleLabel
        );

        headerTextPanel.add(
                subtitleLabel
        );

        JLabel welcomeLabel =
                new JLabel(
                        "ADMIN DASHBOARD"
                );

        welcomeLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        welcomeLabel.setForeground(
                Color.WHITE
        );

        headerPanel.add(
                headerTextPanel,
                BorderLayout.WEST
        );

        headerPanel.add(
                welcomeLabel,
                BorderLayout.EAST
        );

        JPanel statsPanel =
                new JPanel(
                        new GridLayout(
                                1,
                                4,
                                15,
                                15
                        )
                );

        statsPanel.setOpaque(
                false
        );

        JPanel vehicleCard =
                createStatCard(
                        "TOTAL VEHICLES",
                        "0"
                );

        JPanel availableCard =
                createStatCard(
                        "AVAILABLE VEHICLES",
                        "0"
                );

        JPanel customerCard =
                createStatCard(
                        "TOTAL CUSTOMERS",
                        "0"
                );

        JPanel rentalCard =
                createStatCard(
                        "ACTIVE RENTALS",
                        "0"
                );

        totalVehiclesLabel =
                (JLabel)
                vehicleCard.getClientProperty(
                        "valueLabel"
                );

        availableVehiclesLabel =
                (JLabel)
                availableCard.getClientProperty(
                        "valueLabel"
                );

        totalCustomersLabel =
                (JLabel)
                customerCard.getClientProperty(
                        "valueLabel"
                );

        activeRentalsLabel =
                (JLabel)
                rentalCard.getClientProperty(
                        "valueLabel"
                );

        statsPanel.add(
                vehicleCard
        );

        statsPanel.add(
                availableCard
        );

        statsPanel.add(
                customerCard
        );

        statsPanel.add(
                rentalCard
        );

        JPanel managementPanel =
                new JPanel(
                        new BorderLayout(
                                10,
                                10
                        )
                );

        managementPanel.setBackground(
                cardColor
        );

        managementPanel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                20,
                                20,
                                20,
                                20
                        )
                )
        );

        JLabel managementTitle =
                new JLabel(
                        "MANAGEMENT",
                        SwingConstants.LEFT
                );

        managementTitle.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        managementTitle.setForeground(
                textColor
        );

        managementPanel.add(
                managementTitle,
                BorderLayout.NORTH
        );

        JPanel buttonPanel =
                new JPanel(
                        new GridLayout(
                                2,
                                3,
                                15,
                                15
                        )
                );

        buttonPanel.setOpaque(
                false
        );

        JButton vehicleButton =
                createMenuButton(
                        "VEHICLES"
                );

        JButton customerButton =
                createMenuButton(
                        "CUSTOMERS"
                );

        JButton rentalButton =
                createMenuButton(
                        "RENTALS"
                );

        JButton paymentButton =
                createMenuButton(
                        "PAYMENTS"
                );

        JButton reportButton =
                createMenuButton(
                        "REPORTS"
                );

        JButton logoutButton =
                createMenuButton(
                        "LOGOUT"
                );

        buttonPanel.add(
                vehicleButton
        );

        buttonPanel.add(
                customerButton
        );

        buttonPanel.add(
                rentalButton
        );

        buttonPanel.add(
                paymentButton
        );

        buttonPanel.add(
                reportButton
        );

        buttonPanel.add(
                logoutButton
        );

        managementPanel.add(
                buttonPanel,
                BorderLayout.CENTER
        );

        JLabel footerLabel =
                new JLabel(
                        "V-RIDE • Vehicle Rental Management System",
                        SwingConstants.CENTER
                );

        footerLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        12
                )
        );

        footerLabel.setForeground(
                secondaryTextColor
        );

        mainPanel.add(
                headerPanel,
                BorderLayout.NORTH
        );

        JPanel contentPanel =
                new JPanel(
                        new BorderLayout(
                                20,
                                20
                        )
                );

        contentPanel.setOpaque(
                false
        );

        contentPanel.add(
                statsPanel,
                BorderLayout.NORTH
        );

        contentPanel.add(
                managementPanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                contentPanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                footerLabel,
                BorderLayout.SOUTH
        );

        add(
                mainPanel
        );

        vehicleButton.addActionListener(
                e -> {

                    VehicleFrame frame =
                            new VehicleFrame();

                    frame.setVisible(true);
                }
        );

        customerButton.addActionListener(
                e -> {

                    CustomerFrame frame =
                            new CustomerFrame();

                    frame.setVisible(true);
                }
        );

        rentalButton.addActionListener(
                e -> {

                    RentalFrame frame =
                            new RentalFrame();

                    frame.setVisible(true);
                }
        );

        paymentButton.addActionListener(
                e -> {

                    PaymentFrame frame =
                            new PaymentFrame();

                    frame.setVisible(true);
                }
        );

        reportButton.addActionListener(
                e -> {

                    ReportFrame frame =
                            new ReportFrame();

                    frame.setVisible(true);
                }
        );

        logoutButton.addActionListener(
                e -> {

                    int choice =
                            JOptionPane.showConfirmDialog(
                                    this,
                                    "Are you sure you want to logout?",
                                    "Logout",
                                    JOptionPane.YES_NO_OPTION
                            );

                    if (
                            choice
                                    == JOptionPane.YES_OPTION
                    ) {

                        dispose();

                        LoginFrame loginFrame =
                                new LoginFrame();

                        loginFrame.setVisible(true);
                    }
                }
        );

        loadDashboardStats();
    }

    private JPanel createStatCard(
            String title,
            String value
    ) {

        JPanel card =
                new JPanel(
                        new BorderLayout(
                                5,
                                8
                        )
                );

        card.setBackground(
                cardColor
        );

        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                15,
                                15,
                                15,
                                15
                        )
                )
        );

        JLabel titleLabel =
                new JLabel(
                        title,
                        SwingConstants.CENTER
                );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        titleLabel.setForeground(
                secondaryTextColor
        );

        JLabel valueLabel =
                new JLabel(
                        value,
                        SwingConstants.CENTER
                );

        valueLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        30
                )
        );

        valueLabel.setForeground(
                primaryColor
        );

        card.add(
                titleLabel,
                BorderLayout.NORTH
        );

        card.add(
                valueLabel,
                BorderLayout.CENTER
        );

        card.putClientProperty(
                "valueLabel",
                valueLabel
        );

        return card;
    }

    private JButton createMenuButton(
            String text
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        button.setForeground(
                textColor
        );

        button.setBackground(
                new Color(
                        238,
                        241,
                        245
                )
        );

        button.setFocusPainted(
                false
        );

        button.setPreferredSize(
                new Dimension(
                        180,
                        55
                )
        );

        button.setBorder(
                BorderFactory.createLineBorder(
                        borderColor,
                        1
                )
        );

        return button;
    }

    private void loadDashboardStats() {

        try {

            int totalVehicles =
                    reportDAO.getTotalVehicles();

            int availableVehicles =
                    reportDAO.getAvailableVehicles();

            int totalCustomers =
                    reportDAO.getTotalCustomers();

            int totalRentals =
                    reportDAO.getTotalRentals();

            int completedRentals =
                    reportDAO.getCompletedRentals();

            int activeRentals =
                    totalRentals
                    - completedRentals;

            totalVehiclesLabel.setText(
                    String.valueOf(
                            totalVehicles
                    )
            );

            availableVehiclesLabel.setText(
                    String.valueOf(
                            availableVehicles
                    )
            );

            totalCustomersLabel.setText(
                    String.valueOf(
                            totalCustomers
                    )
            );

            activeRentalsLabel.setText(
                    String.valueOf(
                            activeRentals
                    )
            );

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not load dashboard statistics.\n\n"
                            + e.getMessage(),
                    "Dashboard Error",
                    JOptionPane.ERROR_MESSAGE
            );

            e.printStackTrace();
        }
    }

    public static void main(
            String[] args
    ) {

        DashboardFrame dashboardFrame =
                new DashboardFrame();

        dashboardFrame.setVisible(true);
    }
}