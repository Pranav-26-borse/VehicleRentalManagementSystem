package com.vehiclerental.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import com.vehiclerental.dao.VehicleDAO;

public class VehicleFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    private JTextField vehicleNumberField;
    private JTextField brandField;
    private JTextField modelField;
    private JTextField categoryField;
    private JTextField rentalRateField;
    private JTextField searchField;

    private JComboBox<String> statusComboBox;

    private JTable vehicleTable;
    private DefaultTableModel tableModel;

    private int selectedVehicleId = -1;

    private VehicleDAO vehicleDAO;

    private final Color backgroundColor =
            new Color(245, 247, 250);

    private final Color primaryColor =
            new Color(25, 118, 210);

    private final Color primaryDarkColor =
            new Color(13, 71, 161);

    private final Color cardColor =
            Color.WHITE;

    private final Color textColor =
            new Color(35, 40, 45);

    private final Color secondaryTextColor =
            new Color(100, 108, 118);

    private final Color borderColor =
            new Color(220, 225, 230);

    public VehicleFrame() {

        vehicleDAO =
                new VehicleDAO();

        setTitle(
                "V-RIDE - Vehicle Management"
        );

        setSize(
                1100,
                700
        );

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        setLocationRelativeTo(null);

        setResizable(false);

        getContentPane().setBackground(
                backgroundColor
        );

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(
                                15,
                                15
                        )
                );

        mainPanel.setBackground(
                backgroundColor
        );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        25,
                        20,
                        25
                )
        );

        JPanel headerPanel =
                createHeaderPanel();

        JPanel detailsPanel =
                createDetailsPanel();

        JPanel searchPanel =
                createSearchPanel();

        JPanel tablePanel =
                createTablePanel();

        JPanel actionPanel =
                createActionPanel();

        JPanel topPanel =
                new JPanel(
                        new BorderLayout(
                                10,
                                10
                        )
                );

        topPanel.setOpaque(
                false
        );

        topPanel.add(
                detailsPanel,
                BorderLayout.CENTER
        );

        topPanel.add(
                searchPanel,
                BorderLayout.SOUTH
        );

        mainPanel.add(
                headerPanel,
                BorderLayout.NORTH
        );

        mainPanel.add(
                topPanel,
                BorderLayout.CENTER
        );

        JPanel centerPanel =
                new JPanel(
                        new BorderLayout(
                                10,
                                10
                        )
                );

        centerPanel.setOpaque(
                false
        );

        centerPanel.add(
                topPanel,
                BorderLayout.NORTH
        );

        centerPanel.add(
                tablePanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                centerPanel,
                BorderLayout.CENTER
        );

        mainPanel.add(
                actionPanel,
                BorderLayout.SOUTH
        );

        add(
                mainPanel
        );

        loadVehicles();
    }

    private JPanel createHeaderPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setBackground(
                primaryDarkColor
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        15,
                        20,
                        15,
                        20
                )
        );

        JLabel titleLabel =
                new JLabel(
                        "V-RIDE"
                );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        28
                )
        );

        titleLabel.setForeground(
                Color.WHITE
        );

        JLabel subtitleLabel =
                new JLabel(
                        "VEHICLE MANAGEMENT"
                );

        subtitleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        subtitleLabel.setForeground(
                new Color(
                        220,
                        235,
                        255
                )
        );

        JPanel textPanel =
                new JPanel(
                        new GridLayout(
                                2,
                                1,
                                0,
                                2
                        )
                );

        textPanel.setOpaque(
                false
        );

        textPanel.add(
                titleLabel
        );

        textPanel.add(
                subtitleLabel
        );

        JLabel infoLabel =
                new JLabel(
                        "Manage your rental fleet"
                );

        infoLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        infoLabel.setForeground(
                Color.WHITE
        );

        panel.add(
                textPanel,
                BorderLayout.WEST
        );

        panel.add(
                infoLabel,
                BorderLayout.EAST
        );

        return panel;
    }

    private JPanel createDetailsPanel() {

        JPanel panel =
                new JPanel(
                        new GridBagLayout()
                );

        panel.setBackground(
                cardColor
        );

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                15,
                                20,
                                15,
                                20
                        )
                )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets =
                new Insets(
                        5,
                        8,
                        5,
                        8
                );

        gbc.fill =
                GridBagConstraints.HORIZONTAL;

        gbc.weightx = 1;

        JLabel sectionLabel =
                new JLabel(
                        "VEHICLE DETAILS"
                );

        sectionLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        sectionLabel.setForeground(
                textColor
        );

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 6;

        panel.add(
                sectionLabel,
                gbc
        );

        gbc.gridwidth = 1;

        vehicleNumberField =
                createTextField();

        brandField =
                createTextField();

        modelField =
                createTextField();

        categoryField =
                createTextField();

        rentalRateField =
                createTextField();

        statusComboBox =
                new JComboBox<>(
                        new String[] {
                                "AVAILABLE",
                                "RENTED",
                                "MAINTENANCE"
                        }
                );

        statusComboBox.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        addField(
                panel,
                gbc,
                "Vehicle Number",
                vehicleNumberField,
                0,
                1
        );

        addField(
                panel,
                gbc,
                "Brand",
                brandField,
                2,
                1
        );

        addField(
                panel,
                gbc,
                "Model",
                modelField,
                4,
                1
        );

        addField(
                panel,
                gbc,
                "Category",
                categoryField,
                0,
                2
        );

        addField(
                panel,
                gbc,
                "Rental Rate / Day",
                rentalRateField,
                2,
                2
        );

        addField(
                panel,
                gbc,
                "Status",
                statusComboBox,
                4,
                2
        );

        return panel;
    }

    private void addField(
            JPanel panel,
            GridBagConstraints gbc,
            String labelText,
            java.awt.Component component,
            int x,
            int y
    ) {

        JLabel label =
                new JLabel(
                        labelText
                );

        label.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        label.setForeground(
                secondaryTextColor
        );

        gbc.gridx = x;
        gbc.gridy = y;
        gbc.weightx = 0.1;

        panel.add(
                label,
                gbc
        );

        gbc.gridx = x + 1;
        gbc.weightx = 1;

        panel.add(
                component,
                gbc
        );
    }

    private JTextField createTextField() {

        JTextField field =
                new JTextField();

        field.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        field.setPreferredSize(
                new Dimension(
                        150,
                        34
                )
        );

        field.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                5,
                                8,
                                5,
                                8
                        )
                )
        );

        return field;
    }

    private JPanel createSearchPanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout(
                                10,
                                0
                        )
                );

        panel.setBackground(
                cardColor
        );

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                10,
                                15,
                                10,
                                15
                        )
                )
        );

        JLabel searchLabel =
                new JLabel(
                        "SEARCH VEHICLE"
                );

        searchLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        searchLabel.setForeground(
                secondaryTextColor
        );

        searchField =
                new JTextField();

        searchField.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        searchField.setPreferredSize(
                new Dimension(
                        300,
                        34
                )
        );

        searchField.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                5,
                                10,
                                5,
                                10
                        )
                )
        );

        JButton searchButton =
                createButton(
                        "SEARCH",
                        primaryColor
                );

        JButton viewButton =
                createButton(
                        "VIEW ALL",
                        new Color(
                                76,
                                175,
                                80
                        )
                );

        searchButton.addActionListener(
                e -> searchVehicle()
        );

        viewButton.addActionListener(
                e -> {

                    searchField.setText("");

                    loadVehicles();
                }
        );

        searchField.addActionListener(
                e -> searchVehicle()
        );

        panel.add(
                searchLabel,
                BorderLayout.WEST
        );

        panel.add(
                searchField,
                BorderLayout.CENTER
        );

        JPanel searchButtons =
                new JPanel(
                        new GridLayout(
                                1,
                                2,
                                8,
                                0
                        )
                );

        searchButtons.setOpaque(
                false
        );

        searchButtons.add(
                searchButton
        );

        searchButtons.add(
                viewButton
        );

        panel.add(
                searchButtons,
                BorderLayout.EAST
        );

        return panel;
    }

    private JPanel createTablePanel() {

        JPanel panel =
                new JPanel(
                        new BorderLayout()
                );

        panel.setBackground(
                cardColor
        );

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                borderColor,
                                1
                        ),
                        BorderFactory.createEmptyBorder(
                                10,
                                10,
                                10,
                                10
                        )
                )
        );

        tableModel =
                new DefaultTableModel(
                        new String[] {
                                "ID",
                                "Vehicle Number",
                                "Brand",
                                "Model",
                                "Category",
                                "Rate / Day",
                                "Status"
                        },
                        0
                ) {

                    private static final long serialVersionUID = 1L;

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column
                    ) {
                        return false;
                    }
                };

        vehicleTable =
                new JTable(
                        tableModel
                );

        vehicleTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        vehicleTable.setRowHeight(
                32
        );

        vehicleTable.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        13
                )
        );

        vehicleTable.getTableHeader()
                .setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                13
                        )
                );

        vehicleTable.getTableHeader()
                .setPreferredSize(
                        new Dimension(
                                0,
                                36
                        )
                );

        vehicleTable.setShowGrid(
                true
        );

        vehicleTable.setGridColor(
                borderColor
        );

        vehicleTable.setSelectionBackground(
                new Color(
                        225,
                        238,
                        255
                )
        );

        vehicleTable.setSelectionForeground(
                textColor
        );

        vehicleTable.setAutoCreateRowSorter(
                true
        );

        DefaultTableCellRenderer centerRenderer =
                new DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        vehicleTable.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(50);

        vehicleTable.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(150);

        vehicleTable.getColumnModel()
                .getColumn(2)
                .setPreferredWidth(120);

        vehicleTable.getColumnModel()
                .getColumn(3)
                .setPreferredWidth(120);

        vehicleTable.getColumnModel()
                .getColumn(4)
                .setPreferredWidth(120);

        vehicleTable.getColumnModel()
                .getColumn(5)
                .setPreferredWidth(110);

        vehicleTable.getColumnModel()
                .getColumn(6)
                .setPreferredWidth(120);

        vehicleTable.getColumnModel()
                .getColumn(0)
                .setCellRenderer(
                        centerRenderer
                );

        vehicleTable.getColumnModel()
                .getColumn(5)
                .setCellRenderer(
                        centerRenderer
                );

        vehicleTable.getColumnModel()
                .getColumn(6)
                .setCellRenderer(
                        centerRenderer
                );

        JScrollPane scrollPane =
                new JScrollPane(
                        vehicleTable
                );

        scrollPane.setBorder(
                BorderFactory.createTitledBorder(
                        "Vehicle List"
                )
        );

        panel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        vehicleTable.getSelectionModel()
                .addListSelectionListener(
                        e -> {

                            if (
                                    !e.getValueIsAdjusting()
                            ) {

                                loadSelectedVehicle();
                            }
                        }
                );

        vehicleTable.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    @Override
                    public void mouseClicked(
                            java.awt.event.MouseEvent e
                    ) {

                        if (
                                e.getClickCount() == 2
                        ) {

                            loadSelectedVehicle();
                        }
                    }
                }
        );

        return panel;
    }

    private JPanel createActionPanel() {

        JPanel panel =
                new JPanel(
                        new GridLayout(
                                1,
                                5,
                                10,
                                0
                        )
                );

        panel.setOpaque(
                false
        );

        JButton addButton =
                createButton(
                        "ADD VEHICLE",
                        primaryColor
                );

        JButton updateButton =
                createButton(
                        "UPDATE",
                        new Color(
                                255,
                                152,
                                0
                        )
                );

        JButton deleteButton =
                createButton(
                        "DELETE",
                        new Color(
                                211,
                                47,
                                47
                        )
                );

        JButton clearButton =
                createButton(
                        "CLEAR",
                        new Color(
                                96,
                                125,
                                139
                        )
                );

        JButton backButton =
                createButton(
                        "BACK",
                        primaryDarkColor
                );

        addButton.addActionListener(
                e -> addVehicle()
        );

        updateButton.addActionListener(
                e -> updateVehicle()
        );

        deleteButton.addActionListener(
                e -> deleteVehicle()
        );

        clearButton.addActionListener(
                e -> clearFields()
        );

        backButton.addActionListener(
                e -> dispose()
        );

        panel.add(
                addButton
        );

        panel.add(
                updateButton
        );

        panel.add(
                deleteButton
        );

        panel.add(
                clearButton
        );

        panel.add(
                backButton
        );

        return panel;
    }

    private JButton createButton(
            String text,
            Color background
    ) {

        JButton button =
                new JButton(
                        text
                );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                background
        );

        button.setFocusPainted(
                false
        );

        button.setBorder(
                BorderFactory.createEmptyBorder(
                        10,
                        12,
                        10,
                        12
                )
        );

        return button;
    }

    private void loadSelectedVehicle() {

        int row =
                vehicleTable.getSelectedRow();

        if (row == -1) {
            return;
        }

        int modelRow =
                vehicleTable.convertRowIndexToModel(
                        row
                );

        selectedVehicleId =
                Integer.parseInt(
                        tableModel
                                .getValueAt(
                                        modelRow,
                                        0
                                )
                                .toString()
                );

        vehicleNumberField.setText(
                tableModel
                        .getValueAt(
                                modelRow,
                                1
                        )
                        .toString()
        );

        brandField.setText(
                tableModel
                        .getValueAt(
                                modelRow,
                                2
                        )
                        .toString()
        );

        modelField.setText(
                tableModel
                        .getValueAt(
                                modelRow,
                                3
                        )
                        .toString()
        );

        categoryField.setText(
                tableModel
                        .getValueAt(
                                modelRow,
                                4
                        )
                        .toString()
        );

        rentalRateField.setText(
                tableModel
                        .getValueAt(
                                modelRow,
                                5
                        )
                        .toString()
        );

        statusComboBox.setSelectedItem(
                tableModel
                        .getValueAt(
                                modelRow,
                                6
                        )
                        .toString()
        );
    }

    private void addVehicle() {

        if (!validateFields()) {
            return;
        }

        String vehicleNumber =
                vehicleNumberField
                        .getText()
                        .trim();

        String brand =
                brandField
                        .getText()
                        .trim();

        String model =
                modelField
                        .getText()
                        .trim();

        String category =
                categoryField
                        .getText()
                        .trim();

        double rentalRate =
                Double.parseDouble(
                        rentalRateField
                                .getText()
                                .trim()
                );

        String status =
                statusComboBox
                        .getSelectedItem()
                        .toString();

        boolean success =
                vehicleDAO.addVehicle(
                        vehicleNumber,
                        brand,
                        model,
                        category,
                        rentalRate,
                        status
                );

        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vehicle added successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            clearFields();

            loadVehicles();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not add vehicle.\n\n"
                            + "Vehicle number may already exist.",
                    "Vehicle Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void updateVehicle() {

        if (selectedVehicleId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a vehicle from the table first.",
                    "No Vehicle Selected",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (!validateFields()) {
            return;
        }

        String vehicleNumber =
                vehicleNumberField
                        .getText()
                        .trim();

        String brand =
                brandField
                        .getText()
                        .trim();

        String model =
                modelField
                        .getText()
                        .trim();

        String category =
                categoryField
                        .getText()
                        .trim();

        double rentalRate =
                Double.parseDouble(
                        rentalRateField
                                .getText()
                                .trim()
                );

        String status =
                statusComboBox
                        .getSelectedItem()
                        .toString();

        boolean success =
                vehicleDAO.updateVehicle(
                        selectedVehicleId,
                        vehicleNumber,
                        brand,
                        model,
                        category,
                        rentalRate,
                        status
                );

        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vehicle updated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            clearFields();

            loadVehicles();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not update vehicle.",
                    "Vehicle Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void deleteVehicle() {

        if (selectedVehicleId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a vehicle from the table first.",
                    "No Vehicle Selected",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        int choice =
                JOptionPane.showConfirmDialog(
                        this,
                        "Are you sure you want to delete this vehicle?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

        if (
                choice
                        != JOptionPane.YES_OPTION
        ) {

            return;
        }

        boolean success =
                vehicleDAO.deleteVehicle(
                        selectedVehicleId
                );

        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vehicle deleted successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            clearFields();

            loadVehicles();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not delete vehicle.\n\n"
                            + "This vehicle may be linked to an existing rental.",
                    "Vehicle Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void searchVehicle() {

        String keyword =
                searchField
                        .getText()
                        .trim();

        if (keyword.isEmpty()) {

            loadVehicles();

            return;
        }

        List<String[]> vehicles =
                vehicleDAO.searchVehicles(
                        keyword
                );

        tableModel.setRowCount(0);

        for (
                String[] vehicle :
                vehicles
        ) {

            tableModel.addRow(
                    new Object[] {
                            Integer.parseInt(
                                    vehicle[0]
                            ),
                            vehicle[1],
                            vehicle[2],
                            vehicle[3],
                            vehicle[4],
                            Double.parseDouble(
                                    vehicle[5]
                            ),
                            vehicle[6]
                    }
            );
        }

        if (vehicles.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "No vehicle found for: "
                            + keyword,
                    "Search Result",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    private void loadVehicles() {

        List<String[]> vehicles =
                vehicleDAO.getAllVehicles();

        tableModel.setRowCount(0);

        for (
                String[] vehicle :
                vehicles
        ) {

            tableModel.addRow(
                    new Object[] {
                            Integer.parseInt(
                                    vehicle[0]
                            ),
                            vehicle[1],
                            vehicle[2],
                            vehicle[3],
                            vehicle[4],
                            Double.parseDouble(
                                    vehicle[5]
                            ),
                            vehicle[6]
                    }
            );
        }
    }

    private boolean validateFields() {

        if (
                vehicleNumberField
                        .getText()
                        .trim()
                        .isEmpty()
                        ||
                brandField
                        .getText()
                        .trim()
                        .isEmpty()
                        ||
                modelField
                        .getText()
                        .trim()
                        .isEmpty()
                        ||
                categoryField
                        .getText()
                        .trim()
                        .isEmpty()
                        ||
                rentalRateField
                        .getText()
                        .trim()
                        .isEmpty()
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please fill all vehicle details.",
                    "Missing Information",
                    JOptionPane.WARNING_MESSAGE
            );

            return false;
        }

        try {

            double rate =
                    Double.parseDouble(
                            rentalRateField
                                    .getText()
                                    .trim()
                    );

            if (rate <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Rental rate must be greater than 0.",
                        "Invalid Rate",
                        JOptionPane.WARNING_MESSAGE
                );

                return false;
            }

        } catch (
                NumberFormatException e
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Rental rate must be a valid number.",
                    "Invalid Rate",
                    JOptionPane.WARNING_MESSAGE
            );

            return false;
        }

        return true;
    }

    private void clearFields() {

        vehicleNumberField.setText("");
        brandField.setText("");
        modelField.setText("");
        categoryField.setText("");
        rentalRateField.setText("");

        statusComboBox.setSelectedItem(
                "AVAILABLE"
        );

        searchField.setText("");

        vehicleTable.clearSelection();

        selectedVehicleId = -1;

        vehicleNumberField.requestFocus();
    }

    public static void main(
            String[] args
    ) {

        VehicleFrame frame =
                new VehicleFrame();

        frame.setVisible(true);
    }
}