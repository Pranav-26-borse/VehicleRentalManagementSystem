package com.vehiclerental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.vehiclerental.connection.DBConnection;

public class VehicleDAO {

    public boolean addVehicle(
            String vehicleNumber,
            String brand,
            String model,
            String category,
            double rentalRate,
            String status) {

        String sql = "INSERT INTO vehicles "
                + "(vehicle_number, brand, model, category, rental_rate, status) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setString(1, vehicleNumber);
            statement.setString(2, brand);
            statement.setString(3, model);
            statement.setString(4, category);
            statement.setDouble(5, rentalRate);
            statement.setString(6, status);

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateVehicle(
            int vehicleId,
            String vehicleNumber,
            String brand,
            String model,
            String category,
            double rentalRate,
            String status) {

        String sql = "UPDATE vehicles SET "
                + "vehicle_number = ?, "
                + "brand = ?, "
                + "model = ?, "
                + "category = ?, "
                + "rental_rate = ?, "
                + "status = ? "
                + "WHERE vehicle_id = ?";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setString(1, vehicleNumber);
            statement.setString(2, brand);
            statement.setString(3, model);
            statement.setString(4, category);
            statement.setDouble(5, rentalRate);
            statement.setString(6, status);
            statement.setInt(7, vehicleId);

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteVehicle(int vehicleId) {

        String sql = "DELETE FROM vehicles WHERE vehicle_id = ?";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setInt(1, vehicleId);

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<String[]> getAllVehicles() {

        List<String[]> vehicles = new ArrayList<>();

        String sql = "SELECT vehicle_id, vehicle_number, brand, model, "
                + "category, rental_rate, status "
                + "FROM vehicles ORDER BY vehicle_id";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet result = statement.executeQuery()
        ) {

            while (result.next()) {

                String[] vehicle = {
                        String.valueOf(result.getInt("vehicle_id")),
                        result.getString("vehicle_number"),
                        result.getString("brand"),
                        result.getString("model"),
                        result.getString("category"),
                        String.valueOf(result.getDouble("rental_rate")),
                        result.getString("status")
                };

                vehicles.add(vehicle);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return vehicles;
    }

    public List<String[]> searchVehicles(String keyword) {

        List<String[]> vehicles = new ArrayList<>();

        String sql = "SELECT vehicle_id, vehicle_number, brand, model, "
                + "category, rental_rate, status "
                + "FROM vehicles "
                + "WHERE vehicle_number LIKE ? "
                + "OR brand LIKE ? "
                + "OR model LIKE ? "
                + "ORDER BY vehicle_id";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            String searchKeyword = "%" + keyword + "%";

            statement.setString(1, searchKeyword);
            statement.setString(2, searchKeyword);
            statement.setString(3, searchKeyword);

            ResultSet result = statement.executeQuery();

            while (result.next()) {

                String[] vehicle = {
                        String.valueOf(result.getInt("vehicle_id")),
                        result.getString("vehicle_number"),
                        result.getString("brand"),
                        result.getString("model"),
                        result.getString("category"),
                        String.valueOf(result.getDouble("rental_rate")),
                        result.getString("status")
                };

                vehicles.add(vehicle);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return vehicles;
    }
}