package com.vehiclerental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.vehiclerental.connection.DBConnection;

public class CustomerDAO {

    public boolean addCustomer(
            String fullName,
            String phone,
            String email,
            String address,
            String drivingLicense) {

        String sql = "INSERT INTO customers "
                + "(full_name, phone, email, address, driving_license) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setString(1, fullName);
            statement.setString(2, phone);
            statement.setString(3, email);
            statement.setString(4, address);
            statement.setString(5, drivingLicense);

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateCustomer(
            int customerId,
            String fullName,
            String phone,
            String email,
            String address,
            String drivingLicense) {

        String sql = "UPDATE customers SET "
                + "full_name = ?, "
                + "phone = ?, "
                + "email = ?, "
                + "address = ?, "
                + "driving_license = ? "
                + "WHERE customer_id = ?";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setString(1, fullName);
            statement.setString(2, phone);
            statement.setString(3, email);
            statement.setString(4, address);
            statement.setString(5, drivingLicense);
            statement.setInt(6, customerId);

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteCustomer(int customerId) {

        String sql = "DELETE FROM customers WHERE customer_id = ?";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setInt(1, customerId);

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<String[]> getAllCustomers() {

        List<String[]> customers = new ArrayList<>();

        String sql = "SELECT customer_id, full_name, phone, email, "
                + "address, driving_license "
                + "FROM customers ORDER BY customer_id";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet result = statement.executeQuery()
        ) {

            while (result.next()) {

                String[] customer = {
                        String.valueOf(result.getInt("customer_id")),
                        result.getString("full_name"),
                        result.getString("phone"),
                        result.getString("email"),
                        result.getString("address"),
                        result.getString("driving_license")
                };

                customers.add(customer);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return customers;
    }

    public List<String[]> searchCustomers(String keyword) {

        List<String[]> customers = new ArrayList<>();

        String sql = "SELECT customer_id, full_name, phone, email, "
                + "address, driving_license "
                + "FROM customers "
                + "WHERE full_name LIKE ? "
                + "OR phone LIKE ? "
                + "OR email LIKE ? "
                + "OR driving_license LIKE ? "
                + "ORDER BY customer_id";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            String searchKeyword = "%" + keyword + "%";

            statement.setString(1, searchKeyword);
            statement.setString(2, searchKeyword);
            statement.setString(3, searchKeyword);
            statement.setString(4, searchKeyword);

            ResultSet result = statement.executeQuery();

            while (result.next()) {

                String[] customer = {
                        String.valueOf(result.getInt("customer_id")),
                        result.getString("full_name"),
                        result.getString("phone"),
                        result.getString("email"),
                        result.getString("address"),
                        result.getString("driving_license")
                };

                customers.add(customer);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return customers;
    }
}