package com.vehiclerental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.vehiclerental.connection.DBConnection;

public class RentalDAO {

    public boolean addRental(
            int customerId,
            int vehicleId,
            String rentalDate,
            int numberOfDays,
            double rentalAmount,
            double lateFee,
            double totalAmount) {

        String sql = "INSERT INTO rentals "
                + "(customer_id, vehicle_id, rental_date, number_of_days, "
                + "rental_amount, late_fee, total_amount, status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, 'ACTIVE')";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setInt(1, customerId);
            statement.setInt(2, vehicleId);
            statement.setString(3, rentalDate);
            statement.setInt(4, numberOfDays);
            statement.setDouble(5, rentalAmount);
            statement.setDouble(6, lateFee);
            statement.setDouble(7, totalAmount);

            boolean added = statement.executeUpdate() > 0;

            if (added) {
                updateVehicleStatus(vehicleId, "RENTED");
            }

            return added;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean completeRental(
            int rentalId,
            String returnDate,
            double lateFee,
            double totalAmount) {

        String sql = "UPDATE rentals SET "
                + "return_date = ?, "
                + "late_fee = ?, "
                + "total_amount = ?, "
                + "status = 'COMPLETED' "
                + "WHERE rental_id = ?";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setString(1, returnDate);
            statement.setDouble(2, lateFee);
            statement.setDouble(3, totalAmount);
            statement.setInt(4, rentalId);

            boolean completed = statement.executeUpdate() > 0;

            if (completed) {
                int vehicleId = getVehicleIdByRentalId(rentalId);

                if (vehicleId > 0) {
                    updateVehicleStatus(vehicleId, "AVAILABLE");
                }
            }

            return completed;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteRental(int rentalId) {

        String sql = "DELETE FROM rentals WHERE rental_id = ?";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setInt(1, rentalId);

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<String[]> getAllRentals() {

        List<String[]> rentals = new ArrayList<>();

        String sql = "SELECT r.rental_id, "
                + "c.full_name, "
                + "v.vehicle_number, "
                + "r.rental_date, "
                + "r.return_date, "
                + "r.number_of_days, "
                + "r.rental_amount, "
                + "r.late_fee, "
                + "r.total_amount, "
                + "r.status "
                + "FROM rentals r "
                + "JOIN customers c ON r.customer_id = c.customer_id "
                + "JOIN vehicles v ON r.vehicle_id = v.vehicle_id "
                + "ORDER BY r.rental_id";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet result = statement.executeQuery()
        ) {

            while (result.next()) {

                String[] rental = {
                        String.valueOf(result.getInt("rental_id")),
                        result.getString("full_name"),
                        result.getString("vehicle_number"),
                        result.getString("rental_date"),
                        result.getString("return_date"),
                        String.valueOf(result.getInt("number_of_days")),
                        String.valueOf(result.getDouble("rental_amount")),
                        String.valueOf(result.getDouble("late_fee")),
                        String.valueOf(result.getDouble("total_amount")),
                        result.getString("status")
                };

                rentals.add(rental);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rentals;
    }

    public List<String[]> getActiveRentals() {

        List<String[]> rentals = new ArrayList<>();

        String sql = "SELECT r.rental_id, "
                + "c.full_name, "
                + "v.vehicle_number, "
                + "r.rental_date, "
                + "r.number_of_days, "
                + "r.rental_amount, "
                + "r.total_amount "
                + "FROM rentals r "
                + "JOIN customers c ON r.customer_id = c.customer_id "
                + "JOIN vehicles v ON r.vehicle_id = v.vehicle_id "
                + "WHERE r.status = 'ACTIVE' "
                + "ORDER BY r.rental_id";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet result = statement.executeQuery()
        ) {

            while (result.next()) {

                String[] rental = {
                        String.valueOf(result.getInt("rental_id")),
                        result.getString("full_name"),
                        result.getString("vehicle_number"),
                        result.getString("rental_date"),
                        String.valueOf(result.getInt("number_of_days")),
                        String.valueOf(result.getDouble("rental_amount")),
                        String.valueOf(result.getDouble("total_amount"))
                };

                rentals.add(rental);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rentals;
    }

    public int getVehicleIdByRentalId(int rentalId) {

        String sql = "SELECT vehicle_id FROM rentals WHERE rental_id = ?";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setInt(1, rentalId);

            ResultSet result = statement.executeQuery();

            if (result.next()) {
                return result.getInt("vehicle_id");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return -1;
    }

    private boolean updateVehicleStatus(
            int vehicleId,
            String status) {

        String sql = "UPDATE vehicles SET status = ? "
                + "WHERE vehicle_id = ?";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setString(1, status);
            statement.setInt(2, vehicleId);

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}