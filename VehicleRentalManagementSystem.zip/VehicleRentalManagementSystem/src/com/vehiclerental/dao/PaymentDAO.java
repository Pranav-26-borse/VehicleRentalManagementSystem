package com.vehiclerental.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.vehiclerental.connection.DBConnection;

public class PaymentDAO {

    public boolean recordPayment(
            int rentalId,
            String paymentDate,
            double amount,
            String paymentMethod) {

        String sql = "INSERT INTO payments "
                + "(rental_id, payment_date, amount, payment_method, payment_status) "
                + "VALUES (?, ?, ?, ?, 'PAID')";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setInt(1, rentalId);
            statement.setString(2, paymentDate);
            statement.setDouble(3, amount);
            statement.setString(4, paymentMethod);

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<String[]> getPaymentHistory() {

        List<String[]> payments = new ArrayList<>();

        String sql = "SELECT p.payment_id, "
                + "p.rental_id, "
                + "c.full_name, "
                + "v.vehicle_number, "
                + "p.payment_date, "
                + "p.amount, "
                + "p.payment_method, "
                + "p.payment_status "
                + "FROM payments p "
                + "JOIN rentals r ON p.rental_id = r.rental_id "
                + "JOIN customers c ON r.customer_id = c.customer_id "
                + "JOIN vehicles v ON r.vehicle_id = v.vehicle_id "
                + "ORDER BY p.payment_id DESC";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet result = statement.executeQuery()
        ) {

            while (result.next()) {

                String[] payment = {
                        String.valueOf(result.getInt("payment_id")),
                        String.valueOf(result.getInt("rental_id")),
                        result.getString("full_name"),
                        result.getString("vehicle_number"),
                        result.getString("payment_date"),
                        String.valueOf(result.getDouble("amount")),
                        result.getString("payment_method"),
                        result.getString("payment_status")
                };

                payments.add(payment);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return payments;
    }

    public double getTotalRevenue() {

        String sql = "SELECT COALESCE(SUM(amount), 0) AS revenue "
                + "FROM payments "
                + "WHERE payment_status = 'PAID'";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet result = statement.executeQuery()
        ) {

            if (result.next()) {
                return result.getDouble("revenue");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0.0;
    }

    public boolean paymentExistsForRental(int rentalId) {

        String sql = "SELECT COUNT(*) AS total "
                + "FROM payments "
                + "WHERE rental_id = ? "
                + "AND payment_status = 'PAID'";

        try (
                Connection connection = DBConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)
        ) {

            statement.setInt(1, rentalId);

            ResultSet result = statement.executeQuery();

            if (result.next()) {
                return result.getInt("total") > 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}