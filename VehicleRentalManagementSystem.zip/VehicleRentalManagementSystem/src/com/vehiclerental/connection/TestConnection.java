package com.vehiclerental.connection;

import java.sql.Connection;

public class TestConnection {

    public static void main(String[] args) {

        Connection connection = DBConnection.getConnection();

        if (connection != null) {
            System.out.println("SUCCESS: Java is connected to MySQL!");
        } else {
            System.out.println("FAILED: Could not connect to MySQL.");
        }
    }
}